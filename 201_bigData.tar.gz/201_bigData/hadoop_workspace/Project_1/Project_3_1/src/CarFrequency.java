
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class CarFrequency {

  public static class CarFrequencyMapper
       extends Mapper<LongWritable, Text, Text, IntWritable>{
	  private final Text recordKey = new Text("Frequency");
    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
    	String records = value.toString();
		String[] fields = records.split(";");
		
		Text val = new Text(fields[4]);
		double horsepower = Double.parseDouble(val.toString());
		if(horsepower > 200){
			context.write(recordKey, new IntWritable(1));
		}		
    }
  }

  public static class CarFrequencyReducer extends Reducer<Text, Text, Text, Text> {
	  static int count = 0;
    public void reduce(Text key, Iterable<IntWritable> values,Context context) throws IOException, InterruptedException{		
		for (IntWritable value : values) {
			count++;
		}
		context.write(key, new Text("= " + count));
	}
  }

  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "CarFrequency");
    job.setJarByClass(CarFrequency.class);
    job.setMapperClass(CarFrequencyMapper.class);
    job.setReducerClass(CarFrequencyReducer.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}