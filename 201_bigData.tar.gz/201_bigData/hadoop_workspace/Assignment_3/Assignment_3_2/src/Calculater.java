
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Calculater {

  public static class CalculaterMapper
       extends Mapper<LongWritable, Text, Text, Text>{

    public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
    	String record = value.toString();
		String[] fields = record.split("\t");
		Text record1 = new Text(new Text(fields[0]));
		Text val = new Text(fields[2]);
		context.write(record1, val);
    }
  }

  public static class CalculaterReducer extends Reducer<Text, Text, Text, Text> {
    public void reduce(Text key, Iterable<Text> values,Context context) throws IOException, InterruptedException{
		int count = 0;
		double sum = 0;
		double max = 0;
		double min = 0;
		for(Text line : values){
			String lineStr = line.toString();
			count++;
			sum += Double.parseDouble(lineStr);
			if(max < Double.parseDouble(lineStr)){
				max = Double.parseDouble(lineStr);
			}
			if(min >  Double.parseDouble(lineStr)){
				min = Double.parseDouble(lineStr);
			}
		}
		context.write(new Text(key),new Text("COUNT= " + count + ",SUM= " + sum + ",MAX= " + max + ",MIN=" + min));
	}
  }

  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "Calculater");
    job.setJarByClass(Calculater.class);
    job.setMapperClass(CalculaterMapper.class);
    job.setReducerClass(CalculaterReducer.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    FileInputFormat.addInputPath(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    System.exit(job.waitForCompletion(true) ? 0 : 1);
  }
}