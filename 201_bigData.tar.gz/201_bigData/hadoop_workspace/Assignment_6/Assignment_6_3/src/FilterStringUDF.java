import java.io.IOException;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.BagFactory;
import org.apache.pig.data.DataBag;
import org.apache.pig.data.Tuple;

public class FilterStringUDF extends EvalFunc<DataBag>{

	@Override
	public DataBag exec(Tuple record) throws IOException {
		boolean flag = false;
		DataBag result = BagFactory.getInstance().newDefaultBag();
		for(Tuple t : (DataBag)record.get(0)){
			String secField = (String) t.get(0);
			String thirdField = (String) t.get(2);
			String regex = "[0-9]+";
			if(secField.matches(regex) || thirdField.matches(regex)){
				flag = true;
			} else {
				result.add(t);
			}
		}		
		return result;
	}

}
