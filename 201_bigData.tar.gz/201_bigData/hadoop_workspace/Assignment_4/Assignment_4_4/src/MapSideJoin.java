
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MapSideJoin {

  public static class JoinRecordMapper
       extends Mapper<LongWritable, Text, Text, Text>{

	private Map<String, String> mapValues = new HashMap<String, String>();
		
	protected void setup(Context context) throws IOException, InterruptedException{
		super.setup(context);		
		 URI[] cacheFiles = context.getCacheFiles();
		 Path path1 = new Path(cacheFiles[0]);
		 if(path1.getName().equalsIgnoreCase("store_sales.txt")){
			 BufferedReader bufferedReader = new BufferedReader(new FileReader(path1.getName()));
			 String line = bufferedReader.readLine();
			 while(null != line){
				 String[] values = line.split(",");
				 String storeLocation = values[0];
				 String salesAmount = values[1];
				 mapValues.put(storeLocation, salesAmount);
				 line = bufferedReader.readLine();
			 }
			 bufferedReader.close();			 
		 }	
	}
	
  public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String record = value.toString();
        String[] values = record.split(",");
        String storeLocation = values[0];
        String salesAmount = mapValues.get(storeLocation);
        context.write(new Text(record), new Text(salesAmount));
    }
  }
  

  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    conf.set("mapreduce.output.textoutputformat.separator", ",");
    Job job = Job.getInstance(conf, "MapSideJoin");
    job.setJarByClass(MapSideJoin.class);
    job.setMapperClass(JoinRecordMapper.class);    
    job.addCacheFile(new Path("/inputs/mr_inputs/store_sales.txt").toUri());    
    job.setNumReduceTasks(0);    
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);
    FileInputFormat.setInputPaths(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    job.waitForCompletion(true);
  }
}