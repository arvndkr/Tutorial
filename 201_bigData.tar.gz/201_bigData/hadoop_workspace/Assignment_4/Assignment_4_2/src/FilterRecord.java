
import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Counters;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class FilterRecord {
	 private enum COUNTERS{
			FILTERED_RECORDS;
		}

  public static class FilterRecordMapper
       extends Mapper<LongWritable, Text, Text, NullWritable>{

	 
	  
	  public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
	        String record = value.toString();
	        String[] values = record.split("\\s+");
	        if(Integer.parseInt(values[1]) < 10 || Integer.parseInt(values[1]) > 50){
	        	context.getCounter(COUNTERS.FILTERED_RECORDS).increment(1L);
	        	context.write(value, NullWritable.get());
	        }
	    }
  }

  

  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "FilterRecord");
    job.setJarByClass(FilterRecord.class);
    FileInputFormat.setInputPaths(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    job.setMapperClass(FilterRecordMapper.class);    
    job.setNumReduceTasks(0);    
    job.setOutputKeyClass(NullWritable.class);
    job.setOutputValueClass(NullWritable.class);
    int exitCode = job.waitForCompletion(true) ? 0 : 1;
    if(exitCode == 0){
    	Counters counters = job.getCounters();
    
    	System.out.println("Filtered out records : "+counters.findCounter(COUNTERS.FILTERED_RECORDS).getValue());
    }
    System.exit(exitCode);
  }
}