
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class MapSideJoin {

  public static class MapSideJoinMapper
       extends Mapper<LongWritable, Text, Text, Text>{

	  private Map<String, String> mapValues = new HashMap<String,String>();
		
	protected void setup(Context context) throws IOException, InterruptedException{
		super.setup(context);
		
		 URI[] cacheFiles = context.getCacheFiles();
		 Path path1 = new Path(cacheFiles[0]);
		 if(path1.getName().equalsIgnoreCase("module5_ex1_f1")){
			 BufferedReader bufferedReader = new BufferedReader(new FileReader(path1.getName()));
			 String line = bufferedReader.readLine();
			 while(line != null){
				 String[] values = line.split("\t");
				 String storeId = values[0];
				 String storeName = values[1];
				 mapValues.put(storeId, storeName);
				 line = bufferedReader.readLine();
			 }
			 bufferedReader.close();
			 
		 }
	}
	
  public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String record = value.toString();
        String[] fields = record.split("\t");
        String storeId = fields[0];
        String storeName = mapValues.get(storeId);
        context.write(new Text(record), new Text(storeName));
    }
  }

  public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    Job job = Job.getInstance(conf, "MapSideJoin");
    job.setJarByClass(MapSideJoin.class);
    job.setMapperClass(MapSideJoinMapper.class);
    job.addCacheFile(new Path("/inputs/mr_inputs/module5_ex1_f1").toUri());
    job.setNumReduceTasks(0);
    job.setMapOutputKeyClass(Text.class);
    job.setMapOutputValueClass(Text.class);
    FileInputFormat.setInputPaths(job, new Path(args[0]));
    FileOutputFormat.setOutputPath(job, new Path(args[1]));
    job.waitForCompletion(true);
  }
}