/**
 * 
 */
package com.cms.dto;

import java.util.Date;

/**
 * @author ARVIND
 *
 */
public class BlogsCommentDto {

	private int commentId;
	private String commentDesc;
	private int blogsId;
	private Date createdDate;
	
	/**
	 * @return the commentId
	 */
	public int getCommentId() {
		return this.commentId;
	}
	/**
	 * @param commentId the commentId to set
	 */
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	/**
	 * @return the commentDesc
	 */
	public String getCommentDesc() {
		return this.commentDesc;
	}
	/**
	 * @param commentDesc the commentDesc to set
	 */
	public void setCommentDesc(String commentDesc) {
		this.commentDesc = commentDesc;
	}
	/**
	 * @return the blogsId
	 */
	public int getBlogsId() {
		return this.blogsId;
	}
	/**
	 * @param blogsId the blogsId to set
	 */
	public void setBlogsId(int blogsId) {
		this.blogsId = blogsId;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
}
