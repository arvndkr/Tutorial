/**
 * 
 */
package com.cms.service;

import java.util.List;

import com.cms.dto.BlogsCommentDto;
import com.cms.dto.BlogsDto;
import com.cms.entity.BlogsEntity;
import com.cms.entity.TwitterUpdateEntity;
import com.cms.exception.CmsBusinessException;

/**
 * @author M1028078
 *
 */
public interface BlogsService {

	/**
	 * @param blogsDto
	 * @throws CmsBusinessException
	 */
	void updateBlog(BlogsDto blogsDto) throws CmsBusinessException;

	/**
	 * @param blogsDto
	 * @param filePaths
	 * @return
	 * @throws CmsBusinessException
	 */
	boolean saveBlog(BlogsDto blogsDto, List<String> filePaths) throws CmsBusinessException;

	/**
	 * @param blogId
	 * @return
	 * @throws CmsBusinessException
	 */
	boolean deleteBlog(int blogId) throws CmsBusinessException;

	/**
	 * @return
	 * @throws CmsBusinessException
	 */
	List<BlogsEntity> getAllBlogs() throws CmsBusinessException;	

	/**
	 * @param blogsId
	 * @return
	 * @throws CmsBusinessException
	 */
	BlogsEntity getBlog(int blogsId) throws CmsBusinessException;
	
	/**
	 * @param blogsComment
	 * @return
	 * @throws CmsBusinessException
	 */
	boolean saveComments(BlogsCommentDto blogsComment) throws CmsBusinessException;

	/**
	 * @param twitterUpdate
	 * @throws CmsBusinessException
	 */
	void saveTwitterUpdates(TwitterUpdateEntity twitterUpdate) throws CmsBusinessException;

	/**
	 * @param blogsId
	 * @return
	 * @throws CmsBusinessException
	 */
	List<TwitterUpdateEntity> getTwitterUpdates(int blogsId) throws CmsBusinessException;

}
