package com.cms.exception;

public class CmsBusinessException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param message
	 * @param cause
	 */
	public CmsBusinessException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public CmsBusinessException(String message) {
		super(message);
	}	

}
