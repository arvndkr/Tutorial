/**
 * 
 */
package com.cms.dao;

import java.util.List;

import com.cms.dto.BlogsCommentDto;
import com.cms.dto.BlogsDto;
import com.cms.entity.BlogsEntity;
import com.cms.entity.TwitterUpdateEntity;
import com.cms.exception.CmsDataAccessException;

/**
 * @author M1028078
 *
 */
public interface BlogsDao {

	/**
	 * @param blogsDto
	 * @throws CmsDataAccessException
	 */
	void updateBlog(BlogsDto blogsDto) throws CmsDataAccessException;

	/**
	 * @param blogsDto
	 * @param filePaths
	 * @return
	 * @throws CmsDataAccessException
	 */
	boolean saveBlog(BlogsDto blogsDto, List<String> filePaths) throws CmsDataAccessException;

	/**
	 * @param blogId
	 * @throws CmsDataAccessException
	 */
	boolean deleteBlog(int blogId) throws CmsDataAccessException;

	/**
	 * @return
	 * @throws CmsDataAccessException
	 */
	List<BlogsEntity> getAllBlogs() throws CmsDataAccessException;	

	/**
	 * @param blogsId
	 * @return
	 * @throws CmsDataAccessException
	 */
	BlogsEntity getBlog(int blogsId) throws CmsDataAccessException;
	
	/**
	 * @param blogsComment
	 * @return 
	 * @throws CmsDataAccessException
	 */
	boolean saveComments(BlogsCommentDto blogsComment) throws CmsDataAccessException;

	/**
	 * @param twitterUpdate
	 * @throws CmsDataAccessException
	 */
	void saveTwitterUpdates(TwitterUpdateEntity twitterUpdate) throws CmsDataAccessException;

	/**
	 * @param blogsId
	 * @return
	 * @throws CmsDataAccessException
	 */
	List<TwitterUpdateEntity> getTwitterUpdates(int blogsId) throws CmsDataAccessException;

}
