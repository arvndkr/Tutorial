/**
 * 
 */
package com.cms.constant;

/**
 * @author M1028078
 *
 */
public interface CmsConstant {

	public Object NULL = null;
}
