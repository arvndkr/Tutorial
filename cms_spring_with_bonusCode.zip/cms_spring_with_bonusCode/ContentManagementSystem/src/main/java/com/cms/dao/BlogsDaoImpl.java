/**
 * 
 */
package com.cms.dao;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.cms.constant.CmsConstant;
import com.cms.dto.BlogsCommentDto;
import com.cms.dto.BlogsDto;
import com.cms.entity.BlogsAttachmentEntity;
import com.cms.entity.BlogsCommentEntity;
import com.cms.entity.BlogsEntity;
import com.cms.entity.TwitterUpdateEntity;
import com.cms.exception.CmsDataAccessException;
import com.cms.util.CmsHibernateUtil;


/**
 * @author M1028078
 *
 */
@Repository
public class BlogsDaoImpl extends CmsHibernateUtil implements BlogsDao {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * @param blogsDto
	 * @throws CmsDataAccessException
	 */
	@Override
	public void updateBlog(BlogsDto blogsDto) throws CmsDataAccessException{
		Session session = null;
		logger.info("updateBlog: Start");
		try {
			session = getSession();
			BlogsEntity blog = (BlogsEntity) session.load(BlogsEntity.class, blogsDto.getBlogId());
			if (CmsConstant.NULL != blog) {
				blog.setBlogsName(blogsDto.getUpdatedName());;
				blog.setDescription(blogsDto.getUpdatedDes());
				blog.setUploadedBy(blogsDto.getUploadedBy());
				session.saveOrUpdate(blog);
				session.flush();
			}
		} catch (HibernateException e) {
			logger.error("updateBlog: " + e.getMessage(), e);
			throw new CmsDataAccessException("unable to update the blog: ", e);
		} finally {			
			closeSession(session);
		}
	}
	
	/**
	 * @param blogsDto
	 * @param filePaths
	 * @return
	 * @throws CmsDataAccessException
	 */
	@Override
	public boolean saveBlog(BlogsDto blogsDto, List<String> filePaths)
			throws CmsDataAccessException {
		boolean flag = false;		
		Session session = null;
		logger.info("saveBlog: Start");
		BlogsEntity blog = new BlogsEntity();
		blog.setBlogsName(blogsDto.getBlogName());
		blog.setDescription(blogsDto.getDescription());
		blog.setCreatedDate(blogsDto.getCreatedDate());
		blog.setUploadedBy(blogsDto.getUploadedBy());
		try {
			session = getSession();
			session.save(blog);
			for (String filePath : filePaths) {
				BlogsAttachmentEntity blogsAttachment = new BlogsAttachmentEntity();
				blogsAttachment.setAttachmentName(filePath);
				blogsAttachment.setBlogs(blog);
				session.save(blogsAttachment);
			}
			flag = true;
			session.flush();
		} catch (HibernateException e) {
			logger.error("saveBlog: " + e.getMessage(), e);
			throw new CmsDataAccessException("Unable to save Blog", e);
		} finally {			
			closeSession(session);
		}
		return flag;
	}
	
	/**
	 * @param blogId
	 * @throws CmsDataAccessException
	 */
	@Override
	public boolean deleteBlog(int blogId) throws CmsDataAccessException {
		Session session = null;
		boolean flag = false;
		logger.info("deleteBlog: Start");
		try {
			session = getSession();
			BlogsEntity blog = (BlogsEntity) session.load(BlogsEntity.class, blogId);
			if (CmsConstant.NULL != blog) {
				session.delete(blog);
				session.flush();
				flag = true;
			}
		} catch (HibernateException e) {
			logger.error("deleteBlog: " + e.getMessage(), e);
			throw new CmsDataAccessException("unable to delete", e);
		}
		finally {			
			closeSession(session);
		}
		return flag;
	}
	
	/**
	 * @return
	 * @throws CmsDataAccessException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BlogsEntity> getAllBlogs() throws CmsDataAccessException {
		Session session = null;
		List<BlogsEntity> blogs = new ArrayList<BlogsEntity>();
		logger.info("getAllBlogs: Start");
		try {
			session = getSession();
			Query blogsQuery = session.createQuery("from BlogsEntity");
			blogs = blogsQuery.list();
			Collections.sort(blogs);
		} catch (HibernateException e) {
			logger.error("getAllBlogs: " + e.getMessage(), e);
			throw new CmsDataAccessException("unable to get blogs list", e);
		} finally {
			closeSession(session);
		}
		return blogs;
	}
	
	/**
	 * @param blogsId
	 * @return
	 * @throws CmsDataAccessException
	 */
	@Override
	public BlogsEntity getBlog(int blogsId) throws CmsDataAccessException {
		Session session = null;
		BlogsEntity blogs = null;
		logger.info("getBlog: Start");
		try {
			session = getSession();
			blogs = (BlogsEntity) session.get(BlogsEntity.class, blogsId);
			List<BlogsCommentEntity> blogComments = blogs.getBlogsComment();
			Collections.sort(blogComments);
			blogs.setBlogsComment(blogComments);
		} catch (HibernateException e) {
			logger.error("getBlog: " + e.getMessage(), e);
			throw new CmsDataAccessException("unable to get blog for given id: ", e);
		} finally {
			closeSession(session);
		}
		return blogs;
	}
	
	/**
	 * @param blogsComment
	 * @throws CmsDataAccessException
	 */
	@Override
	public boolean saveComments(BlogsCommentDto blogsComment) throws CmsDataAccessException {
		Session session = null;
		boolean flag = false;
		BlogsCommentEntity blogComments = new BlogsCommentEntity();
		logger.info("saveComments: Start");
		try {
			session = getSession();
			BlogsEntity blogs = (BlogsEntity) session.get(BlogsEntity.class, blogsComment.getBlogsId());
			if (CmsConstant.NULL != blogs) {
				blogComments.setBlogs(blogs);
				blogComments.setCommentDesc(blogsComment.getCommentDesc());
				blogComments.setCreatedDate(blogsComment.getCreatedDate());
				session.save(blogComments);
				session.flush();
				flag = true;
			}
		} catch (HibernateException e) {
			logger.error("saveComments: " + e.getMessage(), e);
			throw new CmsDataAccessException("Unable to save comments",	e);
		} finally {
			closeSession(session);
		}
		return flag;
	}
	
	/**
	 * @param twitterUpdate
	 * @throws CmsDataAccessException
	 */
	@Override
	public void saveTwitterUpdates(TwitterUpdateEntity twitterUpdate) throws CmsDataAccessException{
		Session session = null;
		logger.info("updateBlog: Start");
		try {
			session = getSession();			
			session.saveOrUpdate(twitterUpdate);
			session.flush();
		} catch (HibernateException e) {
			logger.error("saveTwitterUpdates: " + e.getMessage(), e);
			throw new CmsDataAccessException("unable to update the saveTwitterUpdates: ", e);
		} finally {			
			closeSession(session);
		}
	}
	
	/**
	 * @param blogsId
	 * @return
	 * @throws CmsDataAccessException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<TwitterUpdateEntity> getTwitterUpdates(int blogsId) throws CmsDataAccessException {
		Session session = null;
		List<TwitterUpdateEntity> twitterUpdates = null;
		logger.info("getAllBlogs: Start");
		try {
			session = getSession();
			Query query = session.createQuery("from TwitterUpdateEntity where blogs.blogsId =:blogsId");
			query.setParameter("blogsId", blogsId);
			twitterUpdates = query.list();
		} catch (HibernateException e) {
			logger.error("getTwitterUpdates: " + e.getMessage(), e);
			throw new CmsDataAccessException("unable to get getTwitterUpdates", e);
		} finally {
			closeSession(session);
		}
		return twitterUpdates;
	}

}
