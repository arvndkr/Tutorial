package com.cms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "blogs_attachment")
public class BlogsAttachmentEntity {

	private int attachmentId;
	private String attachmentName;
	private BlogsEntity blogs;
	
	/**
	 * @return the attachmentId
	 */
	@Id
	@Column(name = "attachment_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getAttachmentId() {
		return this.attachmentId;
	}
	/**
	 * @param attachmentId the attachmentId to set
	 */
	public void setAttachmentId(int attachmentId) {
		this.attachmentId = attachmentId;
	}
	
	/**
	 * @return the attachmentName
	 */
	@Column(name = "attachment_name")
	public String getAttachmentName() {
		return this.attachmentName;
	}
	/**
	 * @param attachmentName the attachmentName to set
	 */
	public void setAttachmentName(String attachmentName) {
		this.attachmentName = attachmentName;
	}
	
	/**
	 * @return the blogs
	 */
	@ManyToOne
	@JoinColumn(name = "blogs_id")
	public BlogsEntity getBlogs() {
		return this.blogs;
	}
	/**
	 * @param blogs the blogs to set
	 */
	public void setBlogs(BlogsEntity blogs) {
		this.blogs = blogs;
	}	

}
