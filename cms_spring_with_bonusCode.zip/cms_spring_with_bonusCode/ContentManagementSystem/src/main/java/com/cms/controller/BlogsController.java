/**
 * 
 */
package com.cms.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.cms.dto.BlogsCommentDto;
import com.cms.dto.BlogsDto;
import com.cms.entity.BlogsEntity;
import com.cms.entity.TwitterUpdateEntity;
import com.cms.exception.CmsBusinessException;
import com.cms.service.BlogsService;
import com.cms.util.FileUploadUtil;

/**
 * This class is used to handle request related to blog.
 * upload/delete/ update.
 * @author M1028078
 *
 */
@Controller
public class BlogsController {
	
	@Autowired
	private BlogsService blogsService;

	@Autowired
	private FileUploadUtil fileUploadUtil;
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * @return the blogsService
	 */
	public BlogsService getBlogsService() {
		return this.blogsService;
	}

	/**
	 * @param blogsService the blogsService to set
	 */
	public void setBlogsService(BlogsService blogsService) {
		this.blogsService = blogsService;
	}

	/**
	 * This method redirects to page for uploading blogs.
	 * @return
	 */
	@RequestMapping(value = "/admin/getUploadPage")
	public ModelAndView getUploadPage() {
		logger.info("getAllBlogs: Start");
		return new ModelAndView("uploadBlogs");
	}
	
	@RequestMapping(value = "/admin/uploadBlogs")
	public String uploadBlogs(@ModelAttribute("blogsDto") BlogsDto blogsDto,
			Model model, Principal principal, HttpServletRequest request) {
		logger.info("uploadBlogs: Start");
		List<MultipartFile> files = blogsDto.getAttachments();
		List<String> filePath = new ArrayList<String>();
		String rootPath = request.getSession().getServletContext().getRealPath("/");
		filePath = fileUploadUtil.uploadFiles(files, filePath, rootPath);

		blogsDto.setCreatedDate(new Date());
		String uploadedBy = principal.getName();
		blogsDto.setUploadedBy(uploadedBy);
		try {
			boolean isSave = blogsService.saveBlog(blogsDto, filePath);
			if(isSave){
				model.addAttribute("isUploaded", "yes");
			}else{
				if(!isSave){					
					model.addAttribute("isUploadedWithoutAttach", "yes");
				}
			}
		} catch (CmsBusinessException e) {
			logger.error("uploadBlogs: " + e.getMessage(), e);
			model.addAttribute("isUploaded", "no");
		}
		return "uploadBlogs";
	}
	
	/**
	 * get base URL.
	 * @param request
	 * @return
	 */
	public String getBaseURL(HttpServletRequest request) {
		String baseUrl = request.getScheme() + "://" + request.getServerName() + ":"
				+ request.getServerPort() + request.getContextPath();
		logger.info("getBaseURL: baseUrl: " + baseUrl);
		return baseUrl;
	}
	
	/**
	 * This method is used to display blogs.
	 * @return
	 */
	@RequestMapping(value = "/getAllBlogs")
	public ModelAndView getAllBlogsPage(Model model, HttpServletRequest request) {
		List<BlogsEntity> blogs = null;
		try {
			logger.info("getAllBlogsPage: Start");
			blogs = blogsService.getAllBlogs();
			model.addAttribute("blogs", blogs);
			model.addAttribute("baseUrl", getBaseURL(request));
		} catch (CmsBusinessException e) {
			logger.error("getAllBlogsPage: " + e.getMessage(), e);
		}		
		logger.info("getAllBlogsPage: End");
		return new ModelAndView("blogs");
	}
	
	@RequestMapping(value = "/admin/deleteBlog/{blogId}")
	public String deleteBlog(Model model, @PathVariable("blogId") int blogId) {
		List<BlogsEntity> blogs = null;
		logger.info("deleteBlog: Start");
		try {
			blogsService.deleteBlog(blogId);
			blogs = blogsService.getAllBlogs();
			model.addAttribute("blogs", blogs);
		} catch (CmsBusinessException e) {
			logger.error("deleteBlog: " + e.getMessage(), e);
		}
		model.addAttribute("deleteMessage", "deleted successfully!");
		return "blogs";
	}
	
	/**
	 * @param model
	 * @param blogId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getBlog/{blogId}")
	public String getBlog(Model model, @PathVariable("blogId") int blogId,
			HttpServletRequest request) {		
		BlogsEntity blog = null;
		List<TwitterUpdateEntity> twitterUpdates = null;
		logger.info("getBlog: Start");
		try {
			blog = blogsService.getBlog(blogId);
		} catch (CmsBusinessException e) {
			logger.error("getBlog: " + e.getMessage(), e);
		}
		model.addAttribute("blog", blog);
		model.addAttribute("twitterUpdates", twitterUpdates);
		BlogsCommentDto blogsComment = new BlogsCommentDto();
		BlogsDto blogsDto = new BlogsDto();
		model.addAttribute("blogsComment", blogsComment);
		model.addAttribute("blogsDto", blogsDto);
		model.addAttribute("baseUrl", getBaseURL(request));
		return "blogDetails";
	}	
	
	/**
	 * @param model
	 * @param blogId
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/admin/editBlog/{blogId}")
	public String editBlog(Model model, @PathVariable("blogId") int blogId,	HttpServletRequest request) {
		BlogsEntity blog = null;
		logger.info("editBlog: Start");
		try {
			blog = blogsService.getBlog(blogId);
		} catch (CmsBusinessException e) {
			logger.error("editBlog: " + e.getMessage(), e);
		}
		model.addAttribute("blog", blog);
		BlogsCommentDto blogsComment = new BlogsCommentDto();
		BlogsDto blogsDto = new BlogsDto();
		model.addAttribute("blogsComment", blogsComment);
		model.addAttribute("blogsDto", blogsDto);
		model.addAttribute("edit", true);
		model.addAttribute("baseUrl", getBaseURL(request));
		return "blogDetails";
	}
	
	@RequestMapping(value = "/updateBlog", method = RequestMethod.POST)
	public String updateBlog(@ModelAttribute("blogsDto") BlogsDto blogsDto, Model model,
			HttpServletRequest request, Principal principal) {
		BlogsEntity blog = null;
		logger.info("updateBlog: Start");
		try {
			String uploadedBy = principal.getName();
			blogsDto.setUploadedBy(uploadedBy);
			blogsService.updateBlog(blogsDto);
			blog = blogsService.getBlog(blogsDto.getBlogId());
			model.addAttribute("updateSuccess", "Updated Successfully!");
		} catch (CmsBusinessException e) {
			logger.error("updateBlog: " + e.getMessage(), e);
		}
		model.addAttribute("blog", blog);
		BlogsCommentDto blogsComment = new BlogsCommentDto();
		model.addAttribute("blogsComment", blogsComment);
		model.addAttribute("blogsDto", new BlogsDto());
		/*model.addAttribute("edit", true);*/
		model.addAttribute("baseUrl", getBaseURL(request));
		return "blogDetails";
	}
	
	@RequestMapping(value = "/addComment", method= RequestMethod.POST)
	public String addComment(Model model, HttpServletRequest request,
			@ModelAttribute("blogsComment") BlogsCommentDto blogsComment) {
		BlogsEntity blog = null;
		logger.info("addComment: Start");
		blogsComment.setCreatedDate(new Date());		
		try {
			blogsService.saveComments(blogsComment);
			blog = blogsService.getBlog(blogsComment.getBlogsId());
		} catch (CmsBusinessException e) {
			logger.error("addComment: " + e.getMessage(), e);
		}
		model.addAttribute("blog", blog);
		model.addAttribute("blogsComment", new BlogsCommentDto());
		model.addAttribute("blogsDto", new BlogsDto());
		model.addAttribute("baseUrl", getBaseURL(request));
		return "blogDetails";
	}
}
