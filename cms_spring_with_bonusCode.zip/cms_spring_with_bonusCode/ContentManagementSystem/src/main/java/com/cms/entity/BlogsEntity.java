package com.cms.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "blogs")
public class BlogsEntity implements Comparable<BlogsEntity>{

	private int blogsId;
	private String blogsName;
	private String description;
	private Date createdDate;
	private List<BlogsAttachmentEntity> blogsAttachment = new ArrayList<BlogsAttachmentEntity>();
	private List<BlogsCommentEntity> blogsComment = new ArrayList<BlogsCommentEntity>();
	private String uploadedBy;
	
	/**
	 * @return the blogsId
	 */
	@Id
	@Column(name = "blogs_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getBlogsId() {
		return this.blogsId;
	}
	/**
	 * @param blogsId the blogsId to set
	 */
	public void setBlogsId(int blogsId) {
		this.blogsId = blogsId;
	}
	/**
	 * @return the blogsName
	 */
	@Column(name = "blogs_name")
	public String getBlogsName() {
		return this.blogsName;
	}
	/**
	 * @param blogsName the blogsName to set
	 */
	public void setBlogsName(String blogsName) {
		this.blogsName = blogsName;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the createdDate
	 */
	@Column(name = "created_date")
	public Date getCreatedDate() {
		return this.createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the blogsAttachment
	 */
	@OneToMany(mappedBy = "blogs", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	public List<BlogsAttachmentEntity> getBlogsAttachment() {
		return this.blogsAttachment;
	}
	/**
	 * @param blogsAttachment the blogsAttachment to set
	 */
	public void setBlogsAttachment(List<BlogsAttachmentEntity> blogsAttachment) {
		this.blogsAttachment = blogsAttachment;
	}
	/**
	 * @return the blogsComment
	 */
	@OneToMany(mappedBy = "blogs", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	public List<BlogsCommentEntity> getBlogsComment() {
		return this.blogsComment;
	}
	/**
	 * @param blogsComment the blogsComment to set
	 */
	public void setBlogsComment(List<BlogsCommentEntity> blogsComment) {
		this.blogsComment = blogsComment;
	}
	/**
	 * @return the uploadedBy
	 */
	@Column(name = "uploaded_by")
	public String getUploadedBy() {
		return this.uploadedBy;
	}
	/**
	 * @param uploadedBy the uploadedBy to set
	 */
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdDate == null) ? 0 : createdDate.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BlogsEntity other = (BlogsEntity) obj;
		if (createdDate == null) {
			if (other.createdDate != null)
				return false;
		} else if (!createdDate.equals(other.createdDate))
			return false;
		return true;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(BlogsEntity blogs) {		
		return blogs.getCreatedDate().compareTo(createdDate);
	}	

}
