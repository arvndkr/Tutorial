package com.cms.entity;

public class User {

}
