/**
 * 
 */
package com.cms.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cms.constant.CmsConstant;
import com.cms.dao.BlogsDao;
import com.cms.dto.BlogsCommentDto;
import com.cms.dto.BlogsDto;
import com.cms.entity.BlogsEntity;
import com.cms.entity.TwitterUpdateEntity;
import com.cms.exception.CmsBusinessException;
import com.cms.exception.CmsDataAccessException;

/**
 * @author M1028078
 *
 */
@Service
public class BlogsServiceImpl implements BlogsService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private BlogsDao blogsDao;
	
	/**
	 * @return the blogsDao
	 */
	public BlogsDao getBlogsDao() {
		return this.blogsDao;
	}

	/**
	 * @param blogsDao the blogsDao to set
	 */
	public void setBlogsDao(BlogsDao blogsDao) {
		this.blogsDao = blogsDao;
	}
	
	/**
	 * This method is used to update blogs detail, name and description.
	 *
	 * @param blogsDto
	 * @throws CmsBusinessException
	 */
	@Override
	public void updateBlog(BlogsDto blogsDto) throws CmsBusinessException {
		try {
			blogsDao.updateBlog(blogsDto);
		} catch (CmsDataAccessException e) {
			logger.error("updateBlog: " + e.getMessage(), e);
			throw new CmsBusinessException(e.getMessage());
		}
	}

	/**
	 * This method is used to save blogs.
	 *
	 * @param blogsDto
	 * @param filePaths
	 * @return
	 * @throws CmsBusinessException
	 */
	@Override
	public boolean saveBlog(BlogsDto blogsDto, List<String> filePaths) throws CmsBusinessException {
		boolean flag = false;
		if (CmsConstant.NULL != blogsDto && filePaths.size() > 0) {
			try {				
				flag = blogsDao.saveBlog(blogsDto, filePaths);
			} catch (CmsDataAccessException e) {
				logger.error("saveBlog: " + e.getMessage(), e);
				throw new CmsBusinessException(e.getMessage());
			}
		}
		return flag;
	}
	
	/**
	 * This method is used to delete blog.
	 *
	 * @param blogId
	 * @return
	 * @throws CmsBusinessException
	 */
	@Override
	public boolean deleteBlog(int blogId) throws CmsBusinessException {
		boolean flag = false;
		try {
			flag = blogsDao.deleteBlog(blogId);
		} catch (CmsDataAccessException e) {
			logger.error("deleteBlog: " + e.getMessage(), e);
			throw new CmsBusinessException(e.getMessage());
		}
		return flag;
	}

	/**
	 * This method is used to get all blog list.
	 *
	 ** @return
	 * @throws CmsBusinessException
	 */
	@Override
	public List<BlogsEntity> getAllBlogs() throws CmsBusinessException {
		List<BlogsEntity> blogs = null;
		try {
			blogs = blogsDao.getAllBlogs();
		} catch (CmsDataAccessException e) {
			logger.error("getAllBlogs: " + e.getMessage(), e);
			throw new CmsBusinessException(e.getMessage());
		}
		return blogs;
	}
	
	/**
	 * @param blogsId
	 * @return
	 * @throws CmsBusinessException
	 */
	@Override
	public BlogsEntity getBlog(int blogsId) throws CmsBusinessException {
		BlogsEntity blog = null;
		try {
			blog =  blogsDao.getBlog(blogsId);
		} catch (CmsDataAccessException e) {
			logger.error("getBlog: " + e.getMessage(), e);
			throw new CmsBusinessException(e.getMessage());
		}
		return blog;
	}

	/**
	 * This method is used to save blog comments.
	 *
	 * @param blogsComment
	 * @return
	 * @throws CmsBusinessException
	 */
	@Override
	public boolean saveComments(BlogsCommentDto blogsComment) throws CmsBusinessException {
		boolean flag = false;
		try {
			flag = blogsDao.saveComments(blogsComment);
		} catch (CmsDataAccessException e) {
			logger.error("saveComments: " + e.getMessage(), e);
			throw new CmsBusinessException(e.getMessage());
		}
		return flag;
	}
	
	/**
	 * @param twitterUpdate
	 * @throws CmsBusinessException
	 */
	@Override
	public void saveTwitterUpdates(TwitterUpdateEntity twitterUpdate) throws CmsBusinessException {
		try {
			blogsDao.saveTwitterUpdates(twitterUpdate);
		} catch (CmsDataAccessException e) {
			logger.error("saveTwitterUpdates: " + e.getMessage(), e);
			throw new CmsBusinessException(e.getMessage());
		}
	}
	
	/**
	 * @param blogsId
	 * @return
	 * @throws CmsBusinessException
	 */
	@Override
	public List<TwitterUpdateEntity> getTwitterUpdates(int blogsId) throws CmsBusinessException {
		List<TwitterUpdateEntity> twitterUpdates = null;
		try {
			twitterUpdates =  blogsDao.getTwitterUpdates(blogsId);
		} catch (CmsDataAccessException e) {
			logger.error("getTwitterUpdates: " + e.getMessage(), e);
			throw new CmsBusinessException(e.getMessage());
		}
		return twitterUpdates;
	}
}
