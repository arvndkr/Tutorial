package com.cms;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;

import com.cms.entity.BlogsAttachmentEntity;
import com.cms.entity.BlogsCommentEntity;
import com.cms.entity.BlogsEntity;

@SpringBootApplication
public class ContentManagementSystemApplication {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public static void main(String[] args) {
		SpringApplication.run(ContentManagementSystemApplication.class, args);
	}
	
	@Autowired
	@Bean(name = "sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource) {
		logger.info("Session factory initialization started");
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
		sessionBuilder.addAnnotatedClasses(BlogsEntity.class);
		sessionBuilder.addAnnotatedClasses(BlogsCommentEntity.class);
		sessionBuilder.addAnnotatedClasses(BlogsAttachmentEntity.class);		
		logger.info("Session factory initialization successful");
		return sessionBuilder.buildSessionFactory();
	}
}
