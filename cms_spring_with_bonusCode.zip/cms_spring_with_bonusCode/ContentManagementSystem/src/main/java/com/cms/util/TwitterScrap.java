package com.cms.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.cms.entity.BlogsEntity;
import com.cms.entity.TwitterUpdateEntity;
import com.cms.exception.CmsBusinessException;
import com.cms.service.BlogsService;

import twitter4j.FilterQuery;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.TwitterStream;
import twitter4j.TwitterStreamFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.json.DataObjectFactory;

public class TwitterScrap {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private BlogsService blogsService;
	private TwitterStream twitterStream;
	private String[] keywords;
	Properties prop = new Properties();
	FileOutputStream fos;
 
	public TwitterScrap() {
		try {
			prop.load(new FileInputStream("twitter.properties")); 
			ConfigurationBuilder cb = new ConfigurationBuilder();			
			cb.setOAuthConsumerKey(prop.getProperty("CONSUMER_KEY"));
			cb.setOAuthConsumerSecret(prop.getProperty("CONSUMER_SECRET"));
			cb.setOAuthAccessToken(prop.getProperty("ACCESS_TOKEN"));
			cb.setOAuthAccessTokenSecret(prop.getProperty("ACCESS_TOKEN_SECRET"));			
			cb.setJSONStoreEnabled(true);
			cb.setIncludeEntitiesEnabled(true);			
			twitterStream = new TwitterStreamFactory(cb.build()).getInstance();
 
		} catch (FileNotFoundException e) {
			logger.error("TwitterScrap: " + e.getMessage(), e);
		} catch (IOException e) {
			logger.error("TwitterScrap: " + e.getMessage(), e);
		}
 
	}
 
	public void startTwitter() {
 
		try {
			fos = new FileOutputStream(new File("twitterstream.json"));
		} catch (IOException e) {
			logger.error("startTwitter: " + e.getMessage(), e);
		}
		List<BlogsEntity> blogs = null;
		//Store the words you are interested in array
		try {
			blogs = blogsService.getAllBlogs();
		} catch (CmsBusinessException e) {
			logger.error("startTwitter: " + e.getMessage(), e);
		}
		for (BlogsEntity blog : blogs) {		
			String keywordString = blog.getBlogsName();
			
			keywords = keywordString.split(",");
			for (int i = 0; i < keywords.length; i++) {
				keywords[i] = keywords[i].trim();
			}
	 
			// Set up the stream's listener (defined above),
			twitterStream.addListener(listener);
	 
			System.out.println("Starting down Twitter sample stream...");
	 
			// Set up a filter to pull out industry-relevant tweets
			FilterQuery query = new FilterQuery().track(keywords);
			twitterStream.filter(query);
		}
	}

	public void stopTwitter() {
		logger.info("Shutting down Twitter sample stream...");
		twitterStream.shutdown(); 
		try {
			fos.close();
		} catch (IOException e) {
			logger.error("stopTwitter: " + e.getMessage(), e);
		}
	}
 
	StatusListener listener = new StatusListener() { 
		// The onStatus method is executed every time a new tweet comes in matching the filter.
		public void onStatus(Status status) {
			// The EventBuilder is used to build an event using the headers and
			// the raw JSON of a tweet
			String newLine = "\r\n";
			System.out.println(status.getUser().getScreenName() + ": " + status.getText() 
			+ status.getGeoLocation());
			
			TwitterUpdateEntity twitterUpdate = new TwitterUpdateEntity();
			twitterUpdate.setTwitterTime(status.getCreatedAt());
			twitterUpdate.setUpdatedDesc(status.getText());
			try {
				blogsService.saveTwitterUpdates(twitterUpdate);
			} catch (CmsBusinessException e) {
				logger.error("onStatus: " + e.getMessage(), e);
			}
 
			System.out.println("timestamp : "+ String.valueOf(status.getCreatedAt().getTime()));
			try {
				fos.write(DataObjectFactory.getRawJSON(status).getBytes());
				fos.write(newLine.getBytes());
			} catch (IOException e) {
				logger.error("onStatus: " + e.getMessage(), e);
			}
 
		}
 
		// This listener will ignore everything except for new tweets
		public void onDeletionNotice(StatusDeletionNotice statusDeletionNotice) {}
		public void onTrackLimitationNotice(int numberOfLimitedStatuses) {}
		public void onScrubGeo(long userId, long upToStatusId) {}
		public void onException(Exception ex) {}
		public void onStallWarning(StallWarning warning) {}
	};	

}
