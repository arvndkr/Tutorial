package com.cms.exception;

public class CmsDataAccessException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	/**
	 * 
	 */
	public CmsDataAccessException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CmsDataAccessException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public CmsDataAccessException(String message) {
		super(message);
	}	

}
