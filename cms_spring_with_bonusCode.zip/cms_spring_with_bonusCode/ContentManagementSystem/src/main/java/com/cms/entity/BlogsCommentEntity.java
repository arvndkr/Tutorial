package com.cms.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "blogs_comment")
public class BlogsCommentEntity implements Comparable<BlogsCommentEntity>{

	private int commentId;
	private String commentDesc;
	private BlogsEntity blogs;
	private Date createdDate;
	
	/**
	 * @return the commentId
	 */
	@Id
	@Column(name = "comment_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getCommentId() {
		return this.commentId;
	}
	/**
	 * @param commentId the commentId to set
	 */
	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}
	/**
	 * @return the commentDesc
	 */
	@Column(name = "comment_desc")
	public String getCommentDesc() {
		return this.commentDesc;
	}
	/**
	 * @param commentDesc the commentDesc to set
	 */
	public void setCommentDesc(String commentDesc) {
		this.commentDesc = commentDesc;
	}
	/**
	 * @return the blogs
	 */
	@ManyToOne
	@JoinColumn(name = "fk_blogs_id")
	public BlogsEntity getBlogs() {
		return this.blogs;
	}
	/**
	 * @param blogs the blogs to set
	 */
	public void setBlogs(BlogsEntity blogs) {
		this.blogs = blogs;
	}
	/**
	 * @return the createdDate
	 */
	@Column(name = "created_date")
	public Date getCreatedDate() {
		return this.createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(BlogsCommentEntity blogsComment) {
		return blogsComment.createdDate.compareTo(createdDate);
	}
	
}
