package com.cms.entity;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author ARVIND
 *
 */
@Entity
@Table(name = "twitter_updates")
public class TwitterUpdateEntity {

	private int updateId;
	private String updatedDesc;
	private BlogsEntity blogs;
	private Date twitterTime;
	/**
	 * @return the updateId
	 */
	@Id
	@Column(name = "update_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getUpdateId() {
		return this.updateId;
	}
	/**
	 * @param updateId the updateId to set
	 */
	public void setUpdateId(int updateId) {
		this.updateId = updateId;
	}
	/**
	 * @return the updatedDesc
	 */
	@Column(name = "updated_desc")
	public String getUpdatedDesc() {
		return this.updatedDesc;
	}
	/**
	 * @param updatedDesc the updatedDesc to set
	 */
	public void setUpdatedDesc(String updatedDesc) {
		this.updatedDesc = updatedDesc;
	}
	/**
	 * @return the blogs
	 */
	@ManyToOne
	@JoinColumn(name = "blog_id")
	public BlogsEntity getBlogs() {
		return this.blogs;
	}
	/**
	 * @param blogs the blogs to set
	 */
	public void setBlogs(BlogsEntity blogs) {
		this.blogs = blogs;
	}
	/**
	 * @return the twitterTime
	 */
	@Column(name = "twitter_time")
	public Date getTwitterTime() {
		return this.twitterTime;
	}
	/**
	 * @param twitterTime the twitterTime to set
	 */
	public void setTwitterTime(Date twitterTime) {
		this.twitterTime = twitterTime;
	}
	
}
