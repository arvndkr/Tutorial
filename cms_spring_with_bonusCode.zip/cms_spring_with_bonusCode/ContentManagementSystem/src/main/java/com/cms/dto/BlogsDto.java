package com.cms.dto;

import java.util.Date;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

/**
 * @author ARVIND
 *
 */
public class BlogsDto {
	
	private int blogId;
	private String blogName;
	private String description;
	private String updatedName;
	private String updatedDes;
	private String uploadedBy;	
	private Date createdDate;
	private List<MultipartFile> attachments;
	
	/**
	 * @return the blogId
	 */
	public int getBlogId() {
		return this.blogId;
	}
	/**
	 * @param blogId the blogId to set
	 */
	public void setBlogId(int blogId) {
		this.blogId = blogId;
	}
	/**
	 * @return the blogName
	 */
	public String getBlogName() {
		return this.blogName;
	}
	/**
	 * @param blogName the blogName to set
	 */
	public void setBlogName(String blogName) {
		this.blogName = blogName;
	}
	/**
	 * @return the description
	 */
	public String getDescription() {
		return this.description;
	}
	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the updatedName
	 */
	public String getUpdatedName() {
		return this.updatedName;
	}
	/**
	 * @param updatedName the updatedName to set
	 */
	public void setUpdatedName(String updatedName) {
		this.updatedName = updatedName;
	}
	/**
	 * @return the updatedDes
	 */
	public String getUpdatedDes() {
		return this.updatedDes;
	}
	/**
	 * @param updatedDes the updatedDes to set
	 */
	public void setUpdatedDes(String updatedDes) {
		this.updatedDes = updatedDes;
	}
	/**
	 * @return the uploadedBy
	 */
	public String getUploadedBy() {
		return this.uploadedBy;
	}
	/**
	 * @param uploadedBy the uploadedBy to set
	 */
	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}
	/**
	 * @return the createdDate
	 */
	public Date getCreatedDate() {
		return this.createdDate;
	}
	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	/**
	 * @return the attachments
	 */
	public List<MultipartFile> getAttachments() {
		return this.attachments;
	}
	/**
	 * @param attachments the attachments to set
	 */
	public void setAttachments(List<MultipartFile> attachments) {
		this.attachments = attachments;
	}
	
	
}
