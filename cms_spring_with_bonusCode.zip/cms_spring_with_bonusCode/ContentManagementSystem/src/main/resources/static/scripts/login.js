$(document).ready(function(){
  /*  $("#register").click(function(){
    	window.location.replace("/register");
    });*/
});