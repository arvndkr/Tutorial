function test(){
	console.log("hi");
}