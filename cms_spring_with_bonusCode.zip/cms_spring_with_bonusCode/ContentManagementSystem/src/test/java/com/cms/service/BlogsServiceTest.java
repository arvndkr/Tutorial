/**
 * 
 */
package com.cms.service;

import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.cms.dao.BlogsDao;
import com.cms.dto.BlogsDto;
import com.cms.entity.BlogsEntity;
import com.cms.exception.CmsBusinessException;
import com.cms.exception.CmsDataAccessException;

/**
 * @author ARVIND
 *
 */
public class BlogsServiceTest {
	BlogsDao blogsDao;
	BlogsServiceImpl blogsServiceImpl;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		blogsServiceImpl = new BlogsServiceImpl();
		blogsDao = Mockito.mock(BlogsDao.class);
		blogsServiceImpl.setBlogsDao(blogsDao);
	}

	@Test
	public void testSaveBlog() {
		BlogsDto blogsDto = new BlogsDto();
		List<String> filePaths = new ArrayList<String>();
		blogsDto.setBlogName("Arvind");
		filePaths.add("Arvind");
		try {
			Mockito.when(blogsDao.saveBlog(blogsDto, filePaths)).thenReturn(true);
			blogsServiceImpl.saveBlog(blogsDto, filePaths);
			verify(blogsDao).saveBlog(blogsDto, filePaths);
		} catch (CmsDataAccessException e) {			
		} catch (CmsBusinessException e) {			
		}
	}
	
	@Test(expected = CmsDataAccessException.class)
	public void testSaveBlogException() throws CmsDataAccessException {
		BlogsDto blogsDto = new BlogsDto();
		List<String> filePaths = new ArrayList<String>();
		blogsDto.setBlogName("Arvind");
		filePaths.add("Arvind");
		try {
			Mockito.doThrow(new CmsDataAccessException()).when(blogsDao).saveBlog(Mockito.any(BlogsDto.class), Mockito.anyList());
			blogsServiceImpl.saveBlog(blogsDto, filePaths);
			verify(blogsDao).saveBlog(blogsDto, filePaths);
		} catch (CmsBusinessException e) {			
		}
	}
	
	@Test
	public void testDeleteBlog() {
		int blogId = 1;
		try {
			Mockito.when(blogsDao.deleteBlog(blogId)).thenReturn(true);
			blogsServiceImpl.deleteBlog(blogId);
			verify(blogsDao).deleteBlog(blogId);
		} catch (CmsDataAccessException e) {			
		} catch (CmsBusinessException e) {			
		}
	}
	
	@Test
	public void testGetAllBlogs() {
		List<BlogsEntity> blogs = new ArrayList<>();
		try {
			Mockito.when(blogsDao.getAllBlogs()).thenReturn(blogs);
			blogsServiceImpl.getAllBlogs();
			verify(blogsDao).getAllBlogs();
		} catch (CmsDataAccessException e) {			
		} catch (CmsBusinessException e) {			
		}
	}
	
	@Test
	public void testGetBlog() {
		BlogsEntity blog = new BlogsEntity();
		int blogId = 1;
		try {
			Mockito.when(blogsDao.getBlog(blogId)).thenReturn(blog);
			blogsServiceImpl.getBlog(blogId);
			verify(blogsDao).getBlog(blogId);
		} catch (CmsDataAccessException e) {			
		} catch (CmsBusinessException e) {			
		}
	}

}
