/**
 * 
 */
package com.cms.dao;

import static org.junit.Assert.fail;

import org.junit.Before;
import org.junit.Test;

/**
 * @author ARVIND
 *
 */
public class BlogsDaoTest {
	BlogsDaoImpl blogsDao;

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
