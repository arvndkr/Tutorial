/**
 * 
 */
package com.hms.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hms.constant.HmsConstant;
import com.hms.dto.BankDetailsDto;
import com.hms.dto.BankExpenseDetailsDto;
import com.hms.dto.ExpenseCategoryDto;
import com.hms.dto.ExpenseDetailsDto;
import com.hms.dto.ExpenseReportDto;
import com.hms.exception.HmsBusinessException;
import com.hms.service.ExpenseService;
import com.hms.util.CalendarUtil;
import com.hms.util.StringUtil;

/**
 * @author ARVIND
 *
 */
@Controller
public class ExpenseController {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private ExpenseService expenseService; 
	
	/**
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/getAllExpense")
	public ModelAndView getAllExpense(Model model, HttpServletRequest request) {		
		try {
			String month = request.getParameter("month");
			logger.info("getAllExpense: Start");
			this.getAllExpenses(model, month);
			//model.addAttribute("baseUrl", getBaseURL(request));
		} catch (HmsBusinessException e) {
			logger.error("getAllExpense: " + e.getMessage(), e);
		}		
		logger.info("getAllExpense: End");
		return new ModelAndView("expenseDetails");
	}

	/**
	 * @param model
	 * @throws HmsBusinessException
	 */
	private void getAllExpenses(Model model, String month) throws HmsBusinessException {
		List<ExpenseDetailsDto> expDetDtos = this.expenseService.getAllExpense(month);
		model.addAttribute("expDetDtos", expDetDtos);
		
		model.addAttribute("month", CalendarUtil.parseMonthYearString(month));
		List<ExpenseCategoryDto> expCatDtos = this.expenseService.getAllCategory(HmsConstant.EXPENSE);
		List<BankDetailsDto> bankDtos = this.expenseService.getAllBanks();
		model.addAttribute("expCatDtos", expCatDtos);
		model.addAttribute("bankDtos", bankDtos);
		
		Double totalExp = this.expenseService.getTotalExpense(month);
		model.addAttribute("totalExp", totalExp);
		model.addAttribute("expenseDetail", new ExpenseDetailsDto());
	}
	
	/**
	 * @param model
	 * @throws HmsBusinessException
	 */
	public void getBankAndCatDetails(Model model, String expCatType) throws HmsBusinessException {
		List<ExpenseCategoryDto> expCatDtos = this.expenseService.getAllCategory(expCatType);
		List<BankDetailsDto> bankDtos = this.expenseService.getAllBanks();
		model.addAttribute("expCatDtos", expCatDtos);
		model.addAttribute("bankDtos", bankDtos);
	}
	
	/**
	 * @param model
	 * @param request
	 * @param expDetDto
	 * @return
	 */
	@RequestMapping(value = "/addExpense", method= RequestMethod.POST)
	public String addExpense(Model model, HttpServletRequest request,
			@ModelAttribute("expenseDetail") ExpenseDetailsDto expDetDto) {
		try {
			String month = expDetDto.getExpDateStr();
			if(StringUtil.isNullOrEmpty(month)){
				month = CalendarUtil.parseMonthYearString(month);
			}
			boolean flag = this.expenseService.addExpense(expDetDto);
			this.getAllExpenses(model, month);
		} catch (HmsBusinessException e) {
			logger.error("addExpense: " + e.getMessage(), e);
		}
		return "expenseDetails";
	}
	
	/**
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/showAddBankExpensePage")
	public ModelAndView showAddBankExpensePage(Model model, HttpServletRequest request) {		
		try {
			logger.info("showAddBankExpensePage: Start");
			this.getBankAndCatDetails(model, HmsConstant.NON_EXPENSE);
			model.addAttribute("bankExpenseDetail", new BankExpenseDetailsDto());
		} catch (HmsBusinessException e) {
			logger.error("showAddBankExpensePage: " + e.getMessage(), e);
		}		
		logger.info("showAddBankExpensePage: End");
		return new ModelAndView("addBankExpense");
	}	

	/**
	 * @param model
	 * @param request
	 * @param bankExpDetailDto
	 * @return
	 */
	@RequestMapping(value = "/addBankExpense", method= RequestMethod.POST)
	public String addBankExpense(Model model, HttpServletRequest request,
			@ModelAttribute("bankExpenseDetail") BankExpenseDetailsDto bankExpDetailDto) {
		try {
			boolean flag = this.expenseService.addBankExpense(bankExpDetailDto);
			this.getBankAndCatDetails(model, HmsConstant.NON_EXPENSE);
			model.addAttribute("bankExpenseDetail", new BankExpenseDetailsDto());
		} catch (HmsBusinessException e) {
			logger.error("addBankExpense: " + e.getMessage(), e);
		}
		return "addBankExpense";
	}
	
	/**
	 * @param model
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "/showMonthlyExpenseReport")
	public ModelAndView getMonthlyExpenseReport(Model model, HttpServletRequest request) {		
		try {
			String month = request.getParameter("month");
			//Double totalExp = this.expenseService.getTotalExpense(month);
			ExpenseReportDto expenseReportDto = this.expenseService.getMonthlyExpenseReport(month);
			model.addAttribute("expenseReportDto", expenseReportDto);
			model.addAttribute("month", CalendarUtil.parseMonthYearString(month));
		} catch (HmsBusinessException e) {
			logger.error("getMonthlyExpenseReport: " + e.getMessage(), e);
		}
		logger.info("getMonthlyExpenseReport: End");
		return new ModelAndView("monthlyExpenseReport");
	}
}
