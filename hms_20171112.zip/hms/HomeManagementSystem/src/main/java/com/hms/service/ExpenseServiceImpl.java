/**
 * 
 */
package com.hms.service;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.constant.HmsConstant;
import com.hms.dao.ExpenseDao;
import com.hms.dto.BankDetailsDto;
import com.hms.dto.BankExpenseDetailsDto;
import com.hms.dto.ExpenseCategoryDto;
import com.hms.dto.ExpenseDetailsDto;
import com.hms.dto.ExpenseReportDto;
import com.hms.exception.HmsBusinessException;
import com.hms.exception.HmsDataAccessException;
import com.hms.util.CalendarUtil;

/**
 * @author ARVIND
 *
 */
@Service
public class ExpenseServiceImpl implements ExpenseService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ExpenseDao expenseDao;
	
	/**
	 * @param monthStr
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public List<ExpenseDetailsDto> getAllExpense(String monthStr) throws HmsBusinessException {
		List<ExpenseDetailsDto> expDetDto = null;
		Date selectedMonth = CalendarUtil.parseStringToMonthYear(monthStr);
		try {
			expDetDto = expenseDao.getAllExpense(selectedMonth);
		} catch (HmsDataAccessException e) {
			logger.error("getAllExpense: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return expDetDto;
	}
	
	/**
	 * @param expCatType
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public List<ExpenseCategoryDto> getAllCategory(String expCatType) throws HmsBusinessException {
		List<ExpenseCategoryDto> expCatDtos = null;
		try {
			expCatDtos = expenseDao.getAllCategory(expCatType);
		} catch (HmsDataAccessException e) {
			logger.error("getAllCategory: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return expCatDtos;
	}
	
	/**
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public List<BankDetailsDto> getAllBanks() throws HmsBusinessException {
		List<BankDetailsDto> bankDtos = null;
		try {
			bankDtos = this.expenseDao.getAllBanks();
		} catch (HmsDataAccessException e) {
			logger.error("getAllCategory: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return bankDtos;
	}
	
	/**
	 * @param expDetDto
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public boolean addExpense(ExpenseDetailsDto expDetDto) throws HmsBusinessException {
		boolean flag = false;
		try {			
			Date expDate = CalendarUtil.parseStringToDate(expDetDto.getExpDateStr());
			expDetDto.setExpDate(expDate);
			flag = this.expenseDao.addExpense(expDetDto);
		} catch (HmsDataAccessException e) {
			logger.error("addExpense: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		} 
		return flag;
	}
	
	/**
	 * @param bankExpDetailDto
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public boolean addBankExpense(BankExpenseDetailsDto bankExpDetailDto) throws HmsBusinessException {
		boolean flag = false;
		try {			
			Date txnDate = CalendarUtil.parseStringToDate(bankExpDetailDto.getTxnDateStr());
			bankExpDetailDto.setTxnDate(txnDate);
			flag = this.expenseDao.addBankExpense(bankExpDetailDto);
		} catch (HmsDataAccessException e) {
			logger.error("addBankExpense: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return flag;
	}
	
	/**
	 * @param monthStr
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public Double getTotalExpense(String monthStr) throws HmsBusinessException {
		Double totalExp;
		Date selectedMonth = CalendarUtil.parseStringToMonthYear(monthStr);
		try {
			totalExp = this.expenseDao.getTotalExpense(selectedMonth);
			if (HmsConstant.NULL == totalExp) {
				totalExp = 0d;
			}
		} catch (HmsDataAccessException e) {
			logger.error("getTotalExpense: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return totalExp;
	}

	/**
	 * @param monthStr
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public ExpenseReportDto getMonthlyExpenseReport(String monthStr) throws HmsBusinessException {
		ExpenseReportDto expenseReportDto = null;
		try {
			Date selectedMonth = CalendarUtil.parseStringToMonthYear(monthStr);
			expenseReportDto = this.expenseDao.getMonthlyExpenseReport(selectedMonth);
		} catch (HmsDataAccessException e) {
			logger.error("getMonthlyExpenseReport: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return expenseReportDto;
	}
	
}
