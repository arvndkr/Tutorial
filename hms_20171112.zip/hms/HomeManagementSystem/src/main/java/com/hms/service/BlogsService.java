/**
 * 
 */
package com.hms.service;

import java.util.List;

import com.hms.dto.BlogsCommentDto;
import com.hms.dto.BlogsDto;
import com.hms.entity.BlogsEntity;
import com.hms.exception.HmsBusinessException;

/**
 * @author M1028078
 *
 */
public interface BlogsService {

	/**
	 * @param blogsDto
	 * @throws HmsBusinessException
	 */
	void updateBlog(BlogsDto blogsDto) throws HmsBusinessException;

	/**
	 * @param blogsDto
	 * @param filePaths
	 * @return
	 * @throws HmsBusinessException
	 */
	boolean saveBlog(BlogsDto blogsDto, List<String> filePaths) throws HmsBusinessException;

	/**
	 * @param blogId
	 * @return
	 * @throws HmsBusinessException
	 */
	boolean deleteBlog(int blogId) throws HmsBusinessException;

	/**
	 * @return
	 * @throws HmsBusinessException
	 */
	List<BlogsEntity> getAllBlogs() throws HmsBusinessException;	

	/**
	 * @param blogsId
	 * @return
	 * @throws HmsBusinessException
	 */
	BlogsEntity getBlog(int blogsId) throws HmsBusinessException;
	
	/**
	 * @param blogsComment
	 * @return
	 * @throws HmsBusinessException
	 */
	boolean saveComments(BlogsCommentDto blogsComment) throws HmsBusinessException;

}
