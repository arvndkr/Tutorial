/**
 * 
 */
package com.hms.dto;

import java.util.Date;

/**
 * @author ARVIND
 *
 */
public class ExpenseDetailsDto implements Comparable<ExpenseDetailsDto> {
	
	private int expenseId;
	private float expenseAmnt;
	private Date expDate;
	private String expDateStr;
	private int expCatId;
	private String expCat;
	private int bankId;
	private String expComment;
	
	/**
	 * @return the expenseId
	 */
	public int getExpenseId() {
		return this.expenseId;
	}
	/**
	 * @param expenseId the expenseId to set
	 */
	public void setExpenseId(int expenseId) {
		this.expenseId = expenseId;
	}
	/**
	 * @return the expenseAmnt
	 */
	public float getExpenseAmnt() {
		return this.expenseAmnt;
	}
	/**
	 * @param expenseAmnt the expenseAmnt to set
	 */
	public void setExpenseAmnt(float expenseAmnt) {
		this.expenseAmnt = expenseAmnt;
	}	
	/**
	 * @return the expDate
	 */
	public Date getExpDate() {
		return this.expDate;
	}
	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}	
	/**
	 * @return the expDateStr
	 */
	public String getExpDateStr() {
		return this.expDateStr;
	}
	/**
	 * @param expDateStr the expDateStr to set
	 */
	public void setExpDateStr(String expDateStr) {
		this.expDateStr = expDateStr;
	}
	/**
	 * @return the expCatId
	 */
	public int getExpCatId() {
		return this.expCatId;
	}
	/**
	 * @param expCatId the expCatId to set
	 */
	public void setExpCatId(int expCatId) {
		this.expCatId = expCatId;
	}
	/**
	 * @return the expCat
	 */
	public String getExpCat() {
		return this.expCat;
	}
	/**
	 * @param expCat the expCat to set
	 */
	public void setExpCat(String expCat) {
		this.expCat = expCat;
	}
	
	/**
	 * @return the bankId
	 */
	public int getBankId() {
		return this.bankId;
	}
	/**
	 * @param bankId the bankId to set
	 */
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	/**
	 * @return the expComment
	 */
	public String getExpComment() {
		return this.expComment;
	}
	/**
	 * @param expComment the expComment to set
	 */
	public void setExpComment(String expComment) {
		this.expComment = expComment;
	}
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ExpenseDetailsDto expDet) {
		if (expDet.getExpDate().compareTo(expDate) == 0) {
			return expDet.getExpenseId() - expenseId;
		} else {
			return expDet.getExpDate().compareTo(expDate);
		}
	}
	
}
