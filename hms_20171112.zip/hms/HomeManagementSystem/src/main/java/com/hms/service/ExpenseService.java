/**
 * 
 */
package com.hms.service;

import java.util.List;

import com.hms.dto.BankDetailsDto;
import com.hms.dto.BankExpenseDetailsDto;
import com.hms.dto.ExpenseCategoryDto;
import com.hms.dto.ExpenseDetailsDto;
import com.hms.dto.ExpenseReportDto;
import com.hms.exception.HmsBusinessException;

/**
 * @author ARVIND
 *
 */
public interface ExpenseService {

	/**
	 * @param month
	 * @return
	 * @throws HmsBusinessException
	 */
	List<ExpenseDetailsDto> getAllExpense(String month) throws HmsBusinessException;

	/**
	 * @param expCatType 
	 * @return
	 * @throws HmsBusinessException
	 */
	List<ExpenseCategoryDto> getAllCategory(String expCatType) throws HmsBusinessException;

	/**
	 * @return
	 * @throws HmsBusinessException
	 */
	List<BankDetailsDto> getAllBanks() throws HmsBusinessException;

	/**
	 * @param expDetDto
	 * @return
	 * @throws HmsBusinessException
	 */
	boolean addExpense(ExpenseDetailsDto expDetDto) throws HmsBusinessException;

	/**
	 * @param bankExpDetailDto
	 * @return
	 * @throws HmsBusinessException
	 */
	boolean addBankExpense(BankExpenseDetailsDto bankExpDetailDto) throws HmsBusinessException;

	/**
	 * @param monthStr
	 * @return
	 * @throws HmsBusinessException
	 */
	Double getTotalExpense(String monthStr) throws HmsBusinessException;

	/**
	 * @param month
	 * @return
	 * @throws HmsBusinessException
	 */
	ExpenseReportDto getMonthlyExpenseReport(String month) throws HmsBusinessException;

}
