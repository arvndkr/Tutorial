/**
 * 
 */
package com.hms.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hms.constant.HmsConstant;
import com.hms.dao.BlogsDao;
import com.hms.dto.BlogsCommentDto;
import com.hms.dto.BlogsDto;
import com.hms.entity.BlogsEntity;
import com.hms.exception.HmsDataAccessException;
import com.hms.exception.HmsBusinessException;

/**
 * @author M1028078
 *
 */
@Service
public class BlogsServiceImpl implements BlogsService {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private BlogsDao blogsDao;
	
	/**
	 * @return the blogsDao
	 */
	public BlogsDao getBlogsDao() {
		return this.blogsDao;
	}

	/**
	 * @param blogsDao the blogsDao to set
	 */
	public void setBlogsDao(BlogsDao blogsDao) {
		this.blogsDao = blogsDao;
	}
	
	/**
	 * This method is used to update blogs detail, name and description.
	 *
	 * @param blogsDto
	 * @throws HmsBusinessException
	 */
	@Override
	public void updateBlog(BlogsDto blogsDto) throws HmsBusinessException {
		try {
			blogsDao.updateBlog(blogsDto);
		} catch (HmsDataAccessException e) {
			logger.error("updateBlog: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
	}

	/**
	 * This method is used to save blogs.
	 *
	 * @param blogsDto
	 * @param filePaths
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public boolean saveBlog(BlogsDto blogsDto, List<String> filePaths) throws HmsBusinessException {
		boolean flag = false;
		if (HmsConstant.NULL != blogsDto && filePaths.size() > 0) {
			try {				
				flag = blogsDao.saveBlog(blogsDto, filePaths);
			} catch (HmsDataAccessException e) {
				logger.error("saveBlog: " + e.getMessage(), e);
				throw new HmsBusinessException(e.getMessage());
			}
		}
		return flag;
	}
	
	/**
	 * This method is used to delete blog.
	 *
	 * @param blogId
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public boolean deleteBlog(int blogId) throws HmsBusinessException {
		boolean flag = false;
		try {
			flag = blogsDao.deleteBlog(blogId);
		} catch (HmsDataAccessException e) {
			logger.error("deleteBlog: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return flag;
	}

	/**
	 * This method is used to get all blog list.
	 *
	 ** @return
	 * @throws HmsBusinessException
	 */
	@Override
	public List<BlogsEntity> getAllBlogs() throws HmsBusinessException {
		List<BlogsEntity> blogs = null;
		try {
			blogs = blogsDao.getAllBlogs();
		} catch (HmsDataAccessException e) {
			logger.error("getAllBlogs: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return blogs;
	}
	
	/**
	 * @param blogsId
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public BlogsEntity getBlog(int blogsId) throws HmsBusinessException {
		BlogsEntity blog = null;
		try {
			blog =  blogsDao.getBlog(blogsId);
		} catch (HmsDataAccessException e) {
			logger.error("getBlog: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return blog;
	}

	/**
	 * This method is used to save blog comments.
	 *
	 * @param blogsComment
	 * @return
	 * @throws HmsBusinessException
	 */
	@Override
	public boolean saveComments(BlogsCommentDto blogsComment) throws HmsBusinessException {
		boolean flag = false;
		try {
			flag = blogsDao.saveComments(blogsComment);
		} catch (HmsDataAccessException e) {
			logger.error("saveComments: " + e.getMessage(), e);
			throw new HmsBusinessException(e.getMessage());
		}
		return flag;
	}
	
}
