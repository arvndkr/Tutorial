package com.hms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "bank_details")
public class BankDetailsEntity{
	private int bankId;
	private String bankName;
	private String accType;
	/**
	 * @return the bankId
	 */
	@Id
	@Column(name = "bank_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getBankId() {
		return this.bankId;
	}
	/**
	 * @param bankId the bankId to set
	 */
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	/**
	 * @return the bankName
	 */
	@Column(name = "bank_name")
	public String getBankName() {
		return this.bankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	/**
	 * @return the accType
	 */
	@Column(name = "account_type")
	public String getAccType() {
		return this.accType;
	}
	/**
	 * @param accType the accType to set
	 */
	public void setAccType(String accType) {
		this.accType = accType;
	}	

}
