package com.hms.entity;

public class User {

}
