package com.hms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "expense_details")
public class ExpenseDetailsEntity implements Comparable<ExpenseDetailsEntity>{

	private int expenseId;
	private float expenseAmnt;
	private Date expDate;
	private ExpenseCategoryEntity expCat;
	private String expComment;
	
	/**
	 * @return the expenseId
	 */
	@Id
	@Column(name = "expense_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getExpenseId() {
		return this.expenseId;
	}

	/**
	 * @param expenseId the expenseId to set
	 */
	public void setExpenseId(int expenseId) {
		this.expenseId = expenseId;
	}

	/**
	 * @return the expenseAmnt
	 */
	@Column(name = "expense_amnt")
	public float getExpenseAmnt() {
		return this.expenseAmnt;
	}

	/**
	 * @param expenseAmnt the expenseAmnt to set
	 */
	public void setExpenseAmnt(float expenseAmnt) {
		this.expenseAmnt = expenseAmnt;
	}	

	/**
	 * @return the expDate
	 */
	@Column(name = "expense_date")
	public Date getExpDate() {
		return this.expDate;
	}

	/**
	 * @param expDate the expDate to set
	 */
	public void setExpDate(Date expDate) {
		this.expDate = expDate;
	}

	/**
	 * @return the expCat
	 */
	@ManyToOne
	@JoinColumn(name = "exp_cat_id")
	public ExpenseCategoryEntity getExpCat() {
		return this.expCat;
	}

	/**
	 * @param expCat the expCat to set
	 */
	public void setExpCat(ExpenseCategoryEntity expCat) {
		this.expCat = expCat;
	}	

	/**
	 * @return the expComment
	 */
	@Column(name = "expense_comment")
	public String getExpComment() {
		return this.expComment;
	}

	/**
	 * @param expComment the expComment to set
	 */
	public void setExpComment(String expComment) {
		this.expComment = expComment;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ExpenseDetailsEntity expDet) {		
		return expDet.getExpDate().compareTo(expDate);
	}

}
