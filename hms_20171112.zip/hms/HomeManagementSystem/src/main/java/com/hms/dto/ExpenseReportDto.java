/**
 * 
 */
package com.hms.dto;

/**
 * @author ARVIND
 *
 */
public class ExpenseReportDto {
	
	private Double totalEarning;
	private Long cashBack;
	private Long refund;
	private Double totalCredit;
	
	private Double actualBankExp;
	private Double totalBankExp;
	private Double totalExp;
	
	private Long expnShopping;
	private Long expnDailyUse;
	private Long expnTrip;
	private Long expnOther;
	
	private float expCurrHdfc;
	private float expDueHdfc;
	private float expCurrCiti;
	private float expDueCiti;
	private float expCurrYes;
	private float expDueYes;
	
	/**
	 * @return the totalEarning
	 */
	public Double getTotalEarning() {
		return this.totalEarning;
	}
	/**
	 * @param totalEarning the totalEarning to set
	 */
	public void setTotalEarning(Double totalEarning) {
		this.totalEarning = totalEarning;
	}
	/**
	 * @return the cashBack
	 */
	public Long getCashBack() {
		return this.cashBack;
	}
	/**
	 * @param cashBack the cashBack to set
	 */
	public void setCashBack(Long cashBack) {
		this.cashBack = cashBack;
	}
	/**
	 * @return the refund
	 */
	public Long getRefund() {
		return this.refund;
	}
	/**
	 * @param refund the refund to set
	 */
	public void setRefund(Long refund) {
		this.refund = refund;
	}
	/**
	 * @return the totalCredit
	 */
	public Double getTotalCredit() {
		return this.totalCredit;
	}
	/**
	 * @param totalCredit the totalCredit to set
	 */
	public void setTotalCredit(Double totalCredit) {
		this.totalCredit = totalCredit;
	}
	/**
	 * @return the actualBankExp
	 */
	public Double getActualBankExp() {
		return this.actualBankExp;
	}
	/**
	 * @param actualBankExp the actualBankExp to set
	 */
	public void setActualBankExp(Double actualBankExp) {
		this.actualBankExp = actualBankExp;
	}
	/**
	 * @return the totalBankExp
	 */
	public Double getTotalBankExp() {
		return this.totalBankExp;
	}
	/**
	 * @param totalBankExp the totalBankExp to set
	 */
	public void setTotalBankExp(Double totalBankExp) {
		this.totalBankExp = totalBankExp;
	}
	/**
	 * @return the totalExp
	 */
	public Double getTotalExp() {
		return this.totalExp;
	}
	/**
	 * @param totalExp the totalExp to set
	 */
	public void setTotalExp(Double totalExp) {
		this.totalExp = totalExp;
	}
	/**
	 * @return the expnShopping
	 */
	public Long getExpnShopping() {
		return this.expnShopping;
	}
	/**
	 * @param expnShopping the expnShopping to set
	 */
	public void setExpnShopping(Long expnShopping) {
		this.expnShopping = expnShopping;
	}
	/**
	 * @return the expnDailyUse
	 */
	public Long getExpnDailyUse() {
		return this.expnDailyUse;
	}
	/**
	 * @param expnDailyUse the expnDailyUse to set
	 */
	public void setExpnDailyUse(Long expnDailyUse) {
		this.expnDailyUse = expnDailyUse;
	}
	/**
	 * @return the expnTrip
	 */
	public Long getExpnTrip() {
		return this.expnTrip;
	}
	/**
	 * @param expnTrip the expnTrip to set
	 */
	public void setExpnTrip(Long expnTrip) {
		this.expnTrip = expnTrip;
	}
	/**
	 * @return the expnOther
	 */
	public Long getExpnOther() {
		return this.expnOther;
	}
	/**
	 * @param expnOther the expnOther to set
	 */
	public void setExpnOther(Long expnOther) {
		this.expnOther = expnOther;
	}
	/**
	 * @return the expCurrHdfc
	 */
	public float getExpCurrHdfc() {
		return this.expCurrHdfc;
	}
	/**
	 * @param expCurrHdfc the expCurrHdfc to set
	 */
	public void setExpCurrHdfc(float expCurrHdfc) {
		this.expCurrHdfc = expCurrHdfc;
	}
	/**
	 * @return the expDueHdfc
	 */
	public float getExpDueHdfc() {
		return this.expDueHdfc;
	}
	/**
	 * @param expDueHdfc the expDueHdfc to set
	 */
	public void setExpDueHdfc(float expDueHdfc) {
		this.expDueHdfc = expDueHdfc;
	}
	/**
	 * @return the expCurrCiti
	 */
	public float getExpCurrCiti() {
		return this.expCurrCiti;
	}
	/**
	 * @param expCurrCiti the expCurrCiti to set
	 */
	public void setExpCurrCiti(float expCurrCiti) {
		this.expCurrCiti = expCurrCiti;
	}
	/**
	 * @return the expDueCiti
	 */
	public float getExpDueCiti() {
		return this.expDueCiti;
	}
	/**
	 * @param expDueCiti the expDueCiti to set
	 */
	public void setExpDueCiti(float expDueCiti) {
		this.expDueCiti = expDueCiti;
	}
	/**
	 * @return the expCurrYes
	 */
	public float getExpCurrYes() {
		return this.expCurrYes;
	}
	/**
	 * @param expCurrYes the expCurrYes to set
	 */
	public void setExpCurrYes(float expCurrYes) {
		this.expCurrYes = expCurrYes;
	}
	/**
	 * @return the expDueYes
	 */
	public float getExpDueYes() {
		return this.expDueYes;
	}
	/**
	 * @param expDueYes the expDueYes to set
	 */
	public void setExpDueYes(float expDueYes) {
		this.expDueYes = expDueYes;
	}
	
}
