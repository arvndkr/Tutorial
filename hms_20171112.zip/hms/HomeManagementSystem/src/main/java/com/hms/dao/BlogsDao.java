/**
 * 
 */
package com.hms.dao;

import java.util.List;

import com.hms.dto.BlogsCommentDto;
import com.hms.dto.BlogsDto;
import com.hms.entity.BlogsEntity;
import com.hms.exception.HmsDataAccessException;

/**
 * @author M1028078
 *
 */
public interface BlogsDao {

	/**
	 * @param blogsDto
	 * @throws HmsDataAccessException
	 */
	void updateBlog(BlogsDto blogsDto) throws HmsDataAccessException;

	/**
	 * @param blogsDto
	 * @param filePaths
	 * @return
	 * @throws HmsDataAccessException
	 */
	boolean saveBlog(BlogsDto blogsDto, List<String> filePaths) throws HmsDataAccessException;

	/**
	 * @param blogId
	 * @throws HmsDataAccessException
	 */
	boolean deleteBlog(int blogId) throws HmsDataAccessException;

	/**
	 * @return
	 * @throws HmsDataAccessException
	 */
	List<BlogsEntity> getAllBlogs() throws HmsDataAccessException;	

	/**
	 * @param blogsId
	 * @return
	 * @throws HmsDataAccessException
	 */
	BlogsEntity getBlog(int blogsId) throws HmsDataAccessException;
	
	/**
	 * @param blogsComment
	 * @return 
	 * @throws HmsDataAccessException
	 */
	boolean saveComments(BlogsCommentDto blogsComment) throws HmsDataAccessException;

}
