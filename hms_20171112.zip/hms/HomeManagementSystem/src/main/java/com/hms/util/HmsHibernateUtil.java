/**
 * 
 */
package com.hms.util;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.hms.constant.HmsConstant;

/**
 * @author M1028078
 *
 */
/**
 *This class is used for setting the Hibernate session factory.
 **/
@Transactional
@Repository
public class HmsHibernateUtil {

	@Autowired
	private SessionFactory sessionFactory;
	
	/**
	 * @return the SessionFactory
	 */
	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}

	/**
	 * @param SessionFactory
	 *        the SessionFactory to set
	 */
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}	

	/**
	 * Get the session object.
	 * @return session
	 */
	protected Session getSession() {
		//Initialize the session object.
		Session session = null;
		//Check for session object null value.
		if (HmsConstant.NULL == session) {
			session = sessionFactory.openSession();
		}
		return session;
	}	
	
	/**
	 * Close DB connection .
	 * Close the session object.
	 * @param session
	 */
	protected void closeSession(Session session) {
		//Check for session object null value.
		if(HmsConstant.NULL != session){
			//Close the session object.
			session.close();
		}
	}
	
}
