/**
 * 
 */
package com.hms.dto;

import java.util.Date;

/**
 * @author ARVIND
 *
 */
public class BankExpenseDetailsDto {
	
	private int bankExpId;
	private float creditAmnt;
	private float debitAmnt;
	private float txnAmnt;
	private float totAmnt;
	private Date txnDate;
	private String txnDateStr;
	private int bankId;
	private String bankName;
	private int toBankId;
	private int expCatId;
	private String expCat;
	private String txnComment;
	/*private ExpenseDetailsDto expDet;*/
	/**
	 * @return the bankExpId
	 */
	public int getBankExpId() {
		return this.bankExpId;
	}
	/**
	 * @param bankExpId the bankExpId to set
	 */
	public void setBankExpId(int bankExpId) {
		this.bankExpId = bankExpId;
	}
	/**
	 * @return the creditAmnt
	 */
	public float getCreditAmnt() {
		return this.creditAmnt;
	}
	/**
	 * @param creditAmnt the creditAmnt to set
	 */
	public void setCreditAmnt(float creditAmnt) {
		this.creditAmnt = creditAmnt;
	}
	/**
	 * @return the debitAmnt
	 */
	public float getDebitAmnt() {
		return this.debitAmnt;
	}
	/**
	 * @param debitAmnt the debitAmnt to set
	 */
	public void setDebitAmnt(float debitAmnt) {
		this.debitAmnt = debitAmnt;
	}	
	/**
	 * @return the txnAmnt
	 */
	public float getTxnAmnt() {
		return this.txnAmnt;
	}
	/**
	 * @param txnAmnt the txnAmnt to set
	 */
	public void setTxnAmnt(float txnAmnt) {
		this.txnAmnt = txnAmnt;
	}
	/**
	 * @return the totAmnt
	 */
	public float getTotAmnt() {
		return this.totAmnt;
	}
	/**
	 * @param totAmnt the totAmnt to set
	 */
	public void setTotAmnt(float totAmnt) {
		this.totAmnt = totAmnt;
	}
	/**
	 * @return the txnDate
	 */
	public Date getTxnDate() {
		return this.txnDate;
	}
	/**
	 * @param txnDate the txnDate to set
	 */
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}	
	/**
	 * @return the txnDateStr
	 */
	public String getTxnDateStr() {
		return this.txnDateStr;
	}
	/**
	 * @param txnDateStr the txnDateStr to set
	 */
	public void setTxnDateStr(String txnDateStr) {
		this.txnDateStr = txnDateStr;
	}
	/**
	 * @return the bankId
	 */
	public int getBankId() {
		return this.bankId;
	}
	/**
	 * @param bankId the bankId to set
	 */
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return this.bankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}	
	/**
	 * @return the toBankId
	 */
	public int getToBankId() {
		return this.toBankId;
	}
	/**
	 * @param toBankId the toBankId to set
	 */
	public void setToBankId(int toBankId) {
		this.toBankId = toBankId;
	}
	/**
	 * @return the expCatId
	 */
	public int getExpCatId() {
		return this.expCatId;
	}
	/**
	 * @param expCatId the expCatId to set
	 */
	public void setExpCatId(int expCatId) {
		this.expCatId = expCatId;
	}
	/**
	 * @return the expCat
	 */
	public String getExpCat() {
		return this.expCat;
	}
	/**
	 * @param expCat the expCat to set
	 */
	public void setExpCat(String expCat) {
		this.expCat = expCat;
	}
	/**
	 * @return the txnComment
	 */
	public String getTxnComment() {
		return this.txnComment;
	}
	/**
	 * @param txnComment the txnComment to set
	 */
	public void setTxnComment(String txnComment) {
		this.txnComment = txnComment;
	}
		

}
