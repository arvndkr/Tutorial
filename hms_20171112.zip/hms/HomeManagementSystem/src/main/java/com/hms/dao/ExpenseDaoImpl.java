/**
 * 
 */
package com.hms.dao;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.hms.constant.HmsConstant;
import com.hms.dto.BankDetailsDto;
import com.hms.dto.BankExpenseDetailsDto;
import com.hms.dto.ExpenseCategoryDto;
import com.hms.dto.ExpenseDetailsDto;
import com.hms.dto.ExpenseReportDto;
import com.hms.entity.BankDetailsEntity;
import com.hms.entity.BankExpenseDetailsEntity;
import com.hms.entity.ExpenseCategoryEntity;
import com.hms.entity.ExpenseDetailsEntity;
import com.hms.exception.HmsDataAccessException;
import com.hms.util.CalendarUtil;
import com.hms.util.HmsHibernateUtil;

/**
 * @author ARVIND
 *
 */
@Repository
public class ExpenseDaoImpl extends HmsHibernateUtil implements ExpenseDao {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * @param selectedMonth
	 * @return
	 * @throws HmsDataAccessException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ExpenseDetailsDto> getAllExpense(Date selectedMonth) throws HmsDataAccessException {
		Session session = null;
		List<ExpenseDetailsEntity> expDetails = null;
		List<ExpenseDetailsDto> expDetDtos  = new ArrayList<ExpenseDetailsDto>();
		logger.info("getAllExpense: Start");
		try {
			session = getSession();
			//Query expDetQuery = session.createQuery("from ExpenseDetailsEntity");
			Query expDetQuery = session.createQuery("select ed from ExpenseDetailsEntity ed where MONTH(ed.expDate) = MONTH(:expDate) and YEAR(expDate) = YEAR(:expDate)");
			expDetQuery.setDate("expDate", selectedMonth);
			expDetails = expDetQuery.list();
			ExpenseDetailsDto expDetDto = null;
			SimpleDateFormat sdf = new SimpleDateFormat(HmsConstant.DATE_FROMAT);
			for (ExpenseDetailsEntity expDet : expDetails) {
				expDetDto = new ExpenseDetailsDto();
				expDetDto.setExpenseId(expDet.getExpenseId());
				expDetDto.setExpenseAmnt(expDet.getExpenseAmnt());
				expDetDto.setExpCatId(expDet.getExpCat().getExpCatId());
				expDetDto.setExpCat(expDet.getExpCat().getExpCat());
				expDetDto.setExpDate(expDet.getExpDate());
				expDetDto.setExpDateStr(sdf.format(expDet.getExpDate()));
				expDetDto.setExpComment(expDet.getExpComment());
				expDetDtos.add(expDetDto);
			}
			Collections.sort(expDetDtos);
		} catch (HibernateException e) {
			logger.error("getAllExpense: " + e.getMessage(), e);
			throw new HmsDataAccessException("unable to get blogs list", e);
		} finally {
			closeSession(session);
		}
		return expDetDtos;
	}
	
	/* (non-Javadoc)
	 * @see com.hms.dao.ExpenseDao#getAllCategory()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<ExpenseCategoryDto> getAllCategory(String expCatType) throws HmsDataAccessException {
		Session session = null;
		List<ExpenseCategoryEntity> expCategories = null;
		List<ExpenseCategoryDto> expCatDtos  = new ArrayList<ExpenseCategoryDto>();
		logger.info("getAllCategory: Start");
		try {
			session = getSession();
			Query expCatQuery = session.createQuery("from ExpenseCategoryEntity where expCatType = :expCatType");
			expCatQuery.setParameter("expCatType", expCatType);
			expCategories = expCatQuery.list();
			ExpenseCategoryDto expCatDto = null;
			for (ExpenseCategoryEntity expCat : expCategories) {
				expCatDto = new ExpenseCategoryDto();
				expCatDto.setExpCatId(expCat.getExpCatId());
				expCatDto.setExpCat(expCat.getExpCat());
				expCatDtos.add(expCatDto);
			}
			Collections.sort(expCatDtos);
		} catch (HibernateException e) {
			logger.error("getAllCategory: " + e.getMessage(), e);
			throw new HmsDataAccessException("getAllCategory: unable to get Category list", e);
		} finally {
			closeSession(session);
		}
		return expCatDtos;
	}
	
	/**
	 * @return
	 * @throws HmsDataAccessException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BankDetailsDto> getAllBanks() throws HmsDataAccessException {
		Session session = null;
		List<BankDetailsEntity> bankDetails = null;
		List<BankDetailsDto> bankDtos  = new ArrayList<BankDetailsDto>();
		logger.info("getAllBanks: Start");
		try {
			session = getSession();
			Query bankQuery = session.createQuery("from BankDetailsEntity");
			bankDetails = bankQuery.list();
			BankDetailsDto bankDto = null;
			for (BankDetailsEntity bankDet : bankDetails) {
				bankDto = new BankDetailsDto();
				bankDto.setBankId(bankDet.getBankId());
				bankDto.setBankName(bankDet.getBankName());
				bankDto.setAccType(bankDet.getAccType());
				bankDtos.add(bankDto);
			}
			//Collections.sort(bankDtos);
		} catch (HibernateException e) {
			logger.error("getAllBanks: " + e.getMessage(), e);
			throw new HmsDataAccessException("getAllBanks: unable to get bank list", e);
		} finally {
			closeSession(session);
		}
		return bankDtos;
	}
	
	/**
	 * @param expDetDto
	 * @return
	 * @throws HmsDataAccessException
	 */
	@Override
	public boolean addExpense(ExpenseDetailsDto expDetDto) throws HmsDataAccessException {
		Session session = null;
		int bankExpId = 0;
		ExpenseDetailsEntity expDet = null;
		logger.info("addExpense: Start");
		try {
			session = getSession();			
			
			expDet = this.saveExpenseDetails(session, expDetDto, expDet);			
			bankExpId = this.saveBankExpenseDetails(expDetDto, session, expDet);
			
		} catch (HibernateException e) {
			logger.error("addExpense: " + e.getMessage(), e);
			throw new HmsDataAccessException("addExpense: unable to get bank list", e);
		} finally {
			closeSession(session);
		}
		return (bankExpId > 0);
	}

	/**
	 * @param expDetDto
	 * @param session
	 * @param expDet
	 * @throws HmsDataAccessException 
	 */
	private int saveBankExpenseDetails(ExpenseDetailsDto expDetDto, Session session,
			ExpenseDetailsEntity expDet) throws HmsDataAccessException {
		
		int bankExpId = 0;
		BankExpenseDetailsEntity bankExpDet  = new BankExpenseDetailsEntity();
		ExpenseCategoryEntity expCat = new ExpenseCategoryEntity();
		BankDetailsEntity bankDetails = new BankDetailsEntity();
		try {
			expCat.setExpCatId(expDetDto.getExpCatId());			
			bankDetails.setBankId(expDetDto.getBankId());
			
			float availableBalance = this.getAvailableBalanceForBank(expDetDto.getBankId());
			float currentBalance = availableBalance - expDetDto.getExpenseAmnt();
			
			bankExpDet.setAvailableBalance(currentBalance);
			bankExpDet.setDebitAmnt(expDetDto.getExpenseAmnt());
			bankExpDet.setTxnDate(expDetDto.getExpDate());
			bankExpDet.setBankDetails(bankDetails);
			bankExpDet.setExpCat(expCat);
			bankExpDet.setExpDet(expDet);
			bankExpDet.setTxnComment(expDetDto.getExpComment());
			bankExpId = (int) session.save(bankExpDet);
		} catch (HibernateException e) {
			logger.error("saveExpenseDetails: " + e.getMessage(), e);
			throw new HmsDataAccessException("saveExpenseDetails: unable to get bank list", e);
		}
		return bankExpId;
	}

	/**
	 * @param session
	 * @return 
	 * @throws HmsDataAccessException 
	 */
	@SuppressWarnings("unchecked")
	private float getAvailableBalanceForBank(int bankId) throws HmsDataAccessException {
		Session session = null;
		float availableBalance = 0;
		List<BankExpenseDetailsEntity> bankExpDet = null;
		try {
			session = getSession();
			Query bankExpQuery = session.createQuery("from BankExpenseDetailsEntity where bankDetails.bankId = :bankId order by bankExpId desc");
			bankExpQuery.setParameter("bankId", bankId);
			bankExpQuery.setMaxResults(1);
			bankExpDet = bankExpQuery.list();
			if (HmsConstant.NULL != bankExpDet && bankExpDet.size() > 0) {
				availableBalance = bankExpDet.get(0).getAvailableBalance();
			}			
		} catch (HibernateException e) {
			logger.error("getAvailableBalanceForBank: " + e.getMessage(), e);
			throw new HmsDataAccessException("getAvailableBalanceForBank: unable to get Available Balance", e);
		} finally {
			closeSession(session);
		}
		return availableBalance;
	}
	
	/**
	 * @param bankId
	 * @param inputDate
	 * @return
	 * @throws HmsDataAccessException
	 */
	private float getAvailableBalanceForBankOnGivenDate(int bankId, Date inputDate) throws HmsDataAccessException {
		Session session = null;
		float availableBalance = 0;
		try {
			session = getSession();
			String hql = "select availableBalance from BankExpenseDetailsEntity where bankDetails.bankId = :bankId and txnDate <= :txnDate order by bankExpId desc";
			Query bankExpQuery = session.createQuery(hql);
			bankExpQuery.setParameter("bankId", bankId);
			bankExpQuery.setDate("txnDate", inputDate);
			bankExpQuery.setMaxResults(1);			
			availableBalance = (float) nullCheckAndFormatting(bankExpQuery.uniqueResult());
		} catch (HibernateException e) {
			logger.error("getAvailableBalanceForBankOnGivenDate: " + e.getMessage(), e);
			throw new HmsDataAccessException("getAvailableBalanceForBankOnGivenDate: unable to get Available Balance", e);
		} finally {
			closeSession(session);
		}
		return availableBalance;
	}

	/**
	 * * @param session
	 * @param expDetDto
	 * @param expDet
	 * @throws HmsDataAccessException 
	 */
	private ExpenseDetailsEntity saveExpenseDetails(Session session, ExpenseDetailsDto expDetDto,
			ExpenseDetailsEntity expDet) throws HmsDataAccessException {
		try {
			expDet = new ExpenseDetailsEntity();
			ExpenseCategoryEntity expCat = new ExpenseCategoryEntity();
			expCat.setExpCatId(expDetDto.getExpCatId());
			
			expDet.setExpenseAmnt(expDetDto.getExpenseAmnt());
			expDet.setExpDate(expDetDto.getExpDate());			
			expDet.setExpCat(expCat);
			expDet.setExpComment(expDetDto.getExpComment());			
			int expId = (int) session.save(expDet);
			expDet.setExpenseId(expId);
		} catch (HibernateException e) {
				logger.error("saveExpenseDetails: " + e.getMessage(), e);
				throw new HmsDataAccessException("saveExpenseDetails: unable to get bank list", e);
		}
		return expDet;
	}
	
	/**
	 * @param bankExpDetailDto
	 * @return
	 * @throws HmsDataAccessException
	 */
	@Override
	public boolean addBankExpense(BankExpenseDetailsDto bankExpDetailDto) throws HmsDataAccessException {
		Session session = null;
		int bankExpId = 0;
		float currentBalance = 0;
		ExpenseCategoryEntity expCat = null;
		BankExpenseDetailsEntity bankExpDet  = new BankExpenseDetailsEntity();
		logger.info("addBankExpense: Start");
		try {
			session = getSession();
			
			expCat = (ExpenseCategoryEntity) session.get(ExpenseCategoryEntity.class, bankExpDetailDto.getExpCatId());
			bankExpDet.setExpCat(expCat);
			
			if (expCat.getExpCat().equalsIgnoreCase("Add Money")
					|| expCat.getExpCat().equalsIgnoreCase("Refund")
					|| expCat.getExpCat().equalsIgnoreCase("Cash Back")) {
				float availableBalance = this.getAvailableBalanceForBank(bankExpDetailDto.getBankId());
				currentBalance = availableBalance + bankExpDetailDto.getTxnAmnt();
				bankExpDet.setCreditAmnt(bankExpDetailDto.getTxnAmnt());
				bankExpId = this.addBankExpenseDetails(bankExpDet, session,
						bankExpDetailDto.getBankId(), bankExpDetailDto, currentBalance);
			} else if (expCat.getExpCat().equalsIgnoreCase("Transfer")){
				bankExpId = this.transferMoney(bankExpDetailDto, session, expCat, bankExpDet);
			} else if (expCat.getExpCat().equalsIgnoreCase("Loan Given")){
				bankExpDetailDto.setToBankId(HmsConstant.LOAN_ID);
				bankExpId = this.transferMoney(bankExpDetailDto, session, expCat, bankExpDet);
			} else if (expCat.getExpCat().equalsIgnoreCase("Loan Return")){
				int toBankId = bankExpDetailDto.getBankId();
				bankExpDetailDto.setBankId(HmsConstant.LOAN_ID);
				bankExpDetailDto.setToBankId(toBankId);
				bankExpId = this.transferMoney(bankExpDetailDto, session, expCat, bankExpDet);
			}
			
		} catch (HibernateException e) {
			logger.error("addBankExpense: " + e.getMessage(), e);
			throw new HmsDataAccessException("addBankExpense: unable to get bank list", e);
		} finally {
			closeSession(session);
		}
		return (bankExpId > 0);
	}

	/**
	 * @param bankExpDetailDto
	 * @param session
	 * @param expCat
	 * @param bankExpDet
	 * @param availableBalance
	 * @return
	 * @throws HmsDataAccessException
	 */
	public int transferMoney(BankExpenseDetailsDto bankExpDetailDto, Session session, ExpenseCategoryEntity expCat,
			BankExpenseDetailsEntity bankExpDet) throws HmsDataAccessException {
		
		float availableBalance = this.getAvailableBalanceForBank(bankExpDetailDto.getBankId());
		float currentBalance = availableBalance - bankExpDetailDto.getTxnAmnt();
		bankExpDet.setDebitAmnt(bankExpDetailDto.getTxnAmnt());
		int bankExpId = this.addBankExpenseDetails(bankExpDet, session,
				bankExpDetailDto.getBankId(), bankExpDetailDto, currentBalance);
		
		bankExpDet = new BankExpenseDetailsEntity();
		bankExpDet.setExpCat(expCat);
		availableBalance = this.getAvailableBalanceForBank(bankExpDetailDto.getToBankId());
		currentBalance = availableBalance + bankExpDetailDto.getTxnAmnt();
		bankExpDet.setCreditAmnt(bankExpDetailDto.getTxnAmnt());
		bankExpId = this.addBankExpenseDetails(bankExpDet, session,
				bankExpDetailDto.getToBankId(), bankExpDetailDto, currentBalance);
		return bankExpId;
	}
	
	private int addBankExpenseDetails(BankExpenseDetailsEntity bankExpDet, Session session, int bankId,
			BankExpenseDetailsDto bankExpDetailDto, float currentBalance) throws HmsDataAccessException {		
		int bankExpId = 0;		
		BankDetailsEntity bankDetails = new BankDetailsEntity();
		try {
			bankDetails.setBankId(bankId);			
			bankExpDet.setAvailableBalance(currentBalance);
			bankExpDet.setTxnDate(bankExpDetailDto.getTxnDate());
			bankExpDet.setBankDetails(bankDetails);			
			bankExpDet.setTxnComment(bankExpDetailDto.getTxnComment());
			//bankExpDet.setExpDet(expDet);
			bankExpId = (int) session.save(bankExpDet);
		} catch (HibernateException e) {
			logger.error("addBankExpenseDetails: " + e.getMessage(), e);
			throw new HmsDataAccessException("addBankExpenseDetails: unable to get bank list", e);
		}
		return bankExpId;
	}

	/**
	 * @param selectedMonth
	 * @return
	 * @throws HmsDataAccessException 
	 */
	@Override
	public Double getTotalExpense(Date selectedMonth) throws HmsDataAccessException {
		Double totalExp = null;
		Session session = null;
		try {
			session = getSession();
			Query addExpQuery = session.createQuery("select SUM(expenseAmnt) from ExpenseDetailsEntity ed where MONTH(ed.expDate) = MONTH(:expDate) and YEAR(ed.expDate) = YEAR(:expDate)");
			addExpQuery.setDate("expDate", selectedMonth);
			totalExp = (Double) addExpQuery.uniqueResult();
			totalExp = this.nullCheckAndFormatting(totalExp);
		} catch (HibernateException e) {
			logger.error("getTotalExpense: " + e.getMessage(), e);
			throw new HmsDataAccessException(e.getMessage());
		} finally {
			closeSession(session);
		}
		return totalExp;
	}

	/**
	 * @param month
	 * @return
	 * @throws HmsDataAccessException
	 */
	@Override
	public ExpenseReportDto getMonthlyExpenseReport(Date selectedMonth) throws HmsDataAccessException {
		Double totalExp = null;
		Double totBankExp = null;
		Double actualBankExp = null;
		Session session = null;
		ExpenseReportDto expenseReportDto = null;
		try {
			session = getSession();
			expenseReportDto = new ExpenseReportDto();
			/*addEarningQuery.setResultTransformer(Transformers.aliasToBean(ExpenseReportDto.class));*/
			totalExp = this.getTotalExpense(selectedMonth);
			
			expenseReportDto.setTotalExp(totalExp);			
			expenseReportDto = this.getEarningDetails(selectedMonth, session, expenseReportDto);
			expenseReportDto = this.getExpenseDetails(selectedMonth, session, expenseReportDto);
			
			totBankExp = expenseReportDto.getTotalBankExp() - expenseReportDto.getRefund();
			actualBankExp = totBankExp - expenseReportDto.getCashBack();
			expenseReportDto.setTotalBankExp(totBankExp);
			expenseReportDto.setActualBankExp(actualBankExp);
			
			expenseReportDto = this.getCreditCardExpenseDetails(selectedMonth, session, expenseReportDto);
			
		} catch (HibernateException e) {
			logger.error("getMonthlyExpenseReport: " + e.getMessage(), e);
			throw new HmsDataAccessException(e.getMessage());
		}catch (Exception e) {
			logger.error("getMonthlyExpenseReport: " + e.getMessage(), e);
			throw new HmsDataAccessException(e.getMessage());
		} finally {
			closeSession(session);
		}
		return expenseReportDto;
	}

	/**
	 * @param inputDate
	 * @param session
	 * @param expenseReportDto
	 * @return
	 * @throws HmsDataAccessException 
	 */
	private ExpenseReportDto getCreditCardExpenseDetails(Date inputDate, Session session,
			ExpenseReportDto expenseReportDto) throws HmsDataAccessException {
		
		int monthDiff = 0;
		int date = CalendarUtil.getCalenderTime(inputDate, Calendar.DATE);
		
		//CITI Bank credit card.
		if(HmsConstant.TO_DATE_CC_CITI >= date){
			monthDiff = HmsConstant.MONTH_DIFF;
		}
		Date toDateCITI = CalendarUtil.getModifiedDate(inputDate, HmsConstant.TO_DATE_CC_CITI, monthDiff);
		float expCurrCiti = getAvailableBalanceForBank(HmsConstant.BANK_ID_CC_CITI);
		float expDueCiti = getAvailableBalanceForBankOnGivenDate(HmsConstant.BANK_ID_CC_CITI, toDateCITI);
		expDueCiti *= -1;
		expCurrCiti *= -1;
		
		//HDFC Bank credit card.
		if(HmsConstant.TO_DATE_CC_HDFC >= date){
			monthDiff = HmsConstant.MONTH_DIFF;
		}
		Date toDateHDFC = CalendarUtil.getModifiedDate(inputDate, HmsConstant.TO_DATE_CC_HDFC, monthDiff);
		float expCurrHdfc = getAvailableBalanceForBank(HmsConstant.BANK_ID_CC_HDFC);
		float expDueHdfc = getAvailableBalanceForBankOnGivenDate(HmsConstant.BANK_ID_CC_HDFC, toDateHDFC);
		expDueHdfc *= -1;
		expCurrHdfc *= -1;
		
		//YES Bank credit card.
		if(HmsConstant.TO_DATE_CC_HDFC >= date){
			monthDiff = HmsConstant.MONTH_DIFF;
		}
		Date toDateYes = CalendarUtil.getModifiedDate(inputDate, HmsConstant.TO_DATE_CC_HDFC, monthDiff);
		float expCurrYes = getAvailableBalanceForBank(HmsConstant.BANK_ID_CC_YES);
		float expDueYes = getAvailableBalanceForBankOnGivenDate(HmsConstant.BANK_ID_CC_YES, toDateYes);
		expDueYes *= -1;
		expCurrYes *= -1;
		
		expenseReportDto.setExpCurrHdfc(expCurrHdfc);
		expenseReportDto.setExpDueHdfc(expDueHdfc);
		expenseReportDto.setExpCurrCiti(expCurrCiti);
		expenseReportDto.setExpDueCiti(expDueCiti);
		expenseReportDto.setExpCurrYes(expCurrYes);
		expenseReportDto.setExpDueYes(expDueYes);
		
		return expenseReportDto;
	}

	/**
	 * @param selectedMonth
	 * @param session
	 * @param expenseReportDto
	 */
	private ExpenseReportDto getExpenseDetails(Date selectedMonth, Session session, ExpenseReportDto expenseReportDto) {
		Double expense = null;
		Double expOther = 0.0;
		Double expTrip = 0.0;
		Double expShopping = 0.0;
		Double expDailyUse = 0.0;
		String category = null;
		Double totalBankExp = 0.0;
				
		String hql = "select SUM(ed.debitAmnt), ed.expCat.expCat from BankExpenseDetailsEntity ed where MONTH(ed.txnDate) = MONTH(:expDate) and YEAR(ed.txnDate) = YEAR(:expDate) and ed.expCat.expCatType = :expCatType group by expCat";
		 
		Query getExpnShoppingQuery = session.createQuery(hql);
		getExpnShoppingQuery.setDate("expDate", selectedMonth);
		getExpnShoppingQuery.setParameter("expCatType", HmsConstant.EXPENSE);
		@SuppressWarnings("unchecked")
		List<Object[]> resultList = getExpnShoppingQuery.list();
		 
		for (Object[] row : resultList) {
			expense = (Double) row[0];
		    category = (String) row[1];
		    expense = this.nullCheckAndFormatting(expense);
		    if(HmsConstant.DAILY_USE.equalsIgnoreCase(category)){
		    	expDailyUse = expense;
		    } else if(HmsConstant.SHOPPING.equalsIgnoreCase(category)){
		    	expShopping = expense;
		    } else if(HmsConstant.TRIP_PARTY_FRIENDS.equalsIgnoreCase(category)
		    		|| HmsConstant.TRIP_PARTY_SELF.equalsIgnoreCase(category)){
		    	expTrip += expense;
		    } else {
		    	expOther = expOther + expense;		    	
		    }
		    totalBankExp += expense;
		    logger.info("category: " + category + " expense: " + expense);
		}
		expenseReportDto.setExpnDailyUse(expDailyUse.longValue());
		expenseReportDto.setExpnShopping(expShopping.longValue());
		expenseReportDto.setExpnOther(expOther.longValue());
		expenseReportDto.setExpnTrip(expTrip.longValue());
		expenseReportDto.setTotalBankExp(totalBankExp);
		return expenseReportDto;
	}

	/**
	 * @param selectedMonth
	 * @param session
	 * @param expenseReportDto
	 */
	private ExpenseReportDto getEarningDetails(Date selectedMonth, Session session, ExpenseReportDto expenseReportDto) {
		
		double totalCreditAmnt = 0;
		
		Query addEarningQuery = session.createQuery("select SUM(creditAmnt) as totalEarning from BankExpenseDetailsEntity bed where bed.expCat.expCatId = :expCatId and MONTH(bed.txnDate) = MONTH(:date) and YEAR(bed.txnDate) = YEAR(:date)");
		addEarningQuery.setDate("date", selectedMonth);
		addEarningQuery.setParameter("expCatId", HmsConstant.CAT_ID_ADD);			
		Double totalEarning = (Double) addEarningQuery.uniqueResult();
		totalEarning = this.nullCheckAndFormatting(totalEarning);
		expenseReportDto.setTotalEarning(totalEarning);
					
		Query addCashBackQuery = session.createQuery("select SUM(creditAmnt) as cashBack from BankExpenseDetailsEntity bed where bed.expCat.expCatId = :expCatId and MONTH(bed.txnDate) = MONTH(:date) and YEAR(bed.txnDate) = YEAR(:date)");
		addCashBackQuery.setDate("date", selectedMonth);
		addCashBackQuery.setParameter("expCatId", HmsConstant.CAT_ID_CASHBACK);
		Double cashBack = (Double) addCashBackQuery.uniqueResult();
		cashBack = this.nullCheckAndFormatting(cashBack);
		expenseReportDto.setCashBack(cashBack.longValue());
		
		Query addRefundQuery = session.createQuery("select SUM(creditAmnt) as refund from BankExpenseDetailsEntity bed where bed.expCat.expCatId = :expCatId and MONTH(bed.txnDate) = MONTH(:date) and YEAR(bed.txnDate) = YEAR(:date)");
		addRefundQuery.setDate("date", selectedMonth);
		addRefundQuery.setParameter("expCatId", HmsConstant.CAT_ID_REFUND);
		Double refund = (Double) addRefundQuery.uniqueResult();
		refund = this.nullCheckAndFormatting(refund);
		expenseReportDto.setRefund(refund.longValue());
		
		totalCreditAmnt = totalEarning + cashBack;
		expenseReportDto.setTotalCredit(nullCheckAndFormatting(totalCreditAmnt));
		return expenseReportDto;
	}

	/**
	 * @param refund
	 * @return
	 */
	private Double nullCheckAndFormatting(Double value) {
		Double result = null;
		if(HmsConstant.NULL == value){
			result = (double) 0;
		} else {
			DecimalFormat df = new DecimalFormat("#.##");
			result = Double.valueOf(df.format(value));
		}
		return result;
	}
	
	private Object nullCheckAndFormatting(Object value) {
		Object result = null;
		if(HmsConstant.NULL == value){
			result = 0f;
		} else {
			result = value;
		}
		return result;
	}

}
