/**
 * 
 */
package com.hms.util;

import com.hms.constant.HmsConstant;

/**
 * @author M1028078
 *
 */
public class StringUtil {
	public static boolean isNullOrEmpty(String input){
		boolean flag = false;
		if(HmsConstant.NULL == input || input.equals("")){
			flag = true;
		}
		return flag;
	}
}
