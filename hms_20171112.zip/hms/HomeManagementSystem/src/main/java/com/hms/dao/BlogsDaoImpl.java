/**
 * 
 */
package com.hms.dao;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.hms.constant.HmsConstant;
import com.hms.dto.BlogsCommentDto;
import com.hms.dto.BlogsDto;
import com.hms.entity.BlogsAttachmentEntity;
import com.hms.entity.BlogsCommentEntity;
import com.hms.entity.BlogsEntity;
import com.hms.exception.HmsDataAccessException;
import com.hms.util.HmsHibernateUtil;


/**
 * @author M1028078
 *
 */
@Repository
public class BlogsDaoImpl extends HmsHibernateUtil implements BlogsDao {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	/**
	 * @param blogsDto
	 * @throws HmsDataAccessException
	 */
	@Override
	public void updateBlog(BlogsDto blogsDto) throws HmsDataAccessException{
		Session session = null;
		logger.info("updateBlog: Start");
		try {
			session = getSession();
			BlogsEntity blog = (BlogsEntity) session.load(BlogsEntity.class, blogsDto.getBlogId());
			if (HmsConstant.NULL != blog) {
				blog.setBlogsName(blogsDto.getUpdatedName());;
				blog.setDescription(blogsDto.getUpdatedDes());
				blog.setUploadedBy(blogsDto.getUploadedBy());
				session.saveOrUpdate(blog);
				session.flush();
			}
		} catch (HibernateException e) {
			logger.error("updateBlog: " + e.getMessage(), e);
			throw new HmsDataAccessException("unable to update the blog: ", e);
		} finally {			
			closeSession(session);
		}
	}
	
	/**
	 * @param blogsDto
	 * @param filePaths
	 * @return
	 * @throws HmsDataAccessException
	 */
	@Override
	public boolean saveBlog(BlogsDto blogsDto, List<String> filePaths)
			throws HmsDataAccessException {
		boolean flag = false;		
		Session session = null;
		logger.info("saveBlog: Start");
		BlogsEntity blog = new BlogsEntity();
		blog.setBlogsName(blogsDto.getBlogName());
		blog.setDescription(blogsDto.getDescription());
		blog.setCreatedDate(blogsDto.getCreatedDate());
		blog.setUploadedBy(blogsDto.getUploadedBy());
		try {
			session = getSession();
			session.save(blog);
			for (String filePath : filePaths) {
				BlogsAttachmentEntity blogsAttachment = new BlogsAttachmentEntity();
				blogsAttachment.setAttachmentName(filePath);
				blogsAttachment.setBlogs(blog);
				session.save(blogsAttachment);
			}
			flag = true;
			session.flush();
		} catch (HibernateException e) {
			logger.error("saveBlog: " + e.getMessage(), e);
			throw new HmsDataAccessException("Unable to save Blog", e);
		} finally {			
			closeSession(session);
		}
		return flag;
	}
	
	/**
	 * @param blogId
	 * @throws HmsDataAccessException
	 */
	@Override
	public boolean deleteBlog(int blogId) throws HmsDataAccessException {
		Session session = null;
		boolean flag = false;
		logger.info("deleteBlog: Start");
		try {
			session = getSession();
			BlogsEntity blog = (BlogsEntity) session.load(BlogsEntity.class, blogId);
			if (HmsConstant.NULL != blog) {
				session.delete(blog);
				session.flush();
				flag = true;
			}
		} catch (HibernateException e) {
			logger.error("deleteBlog: " + e.getMessage(), e);
			throw new HmsDataAccessException("unable to delete", e);
		}
		finally {			
			closeSession(session);
		}
		return flag;
	}
	
	/**
	 * @return
	 * @throws HmsDataAccessException
	 */
	@SuppressWarnings("unchecked")
	@Override
	public List<BlogsEntity> getAllBlogs() throws HmsDataAccessException {
		Session session = null;
		List<BlogsEntity> blogs = new ArrayList<BlogsEntity>();
		logger.info("getAllBlogs: Start");
		try {
			session = getSession();
			Query blogsQuery = session.createQuery("from BlogsEntity");
			blogs = blogsQuery.list();
			Collections.sort(blogs);
		} catch (HibernateException e) {
			logger.error("getAllBlogs: " + e.getMessage(), e);
			throw new HmsDataAccessException("unable to get blogs list", e);
		} finally {
			closeSession(session);
		}
		return blogs;
	}
	
	/**
	 * @param blogsId
	 * @return
	 * @throws HmsDataAccessException
	 */
	@Override
	public BlogsEntity getBlog(int blogsId) throws HmsDataAccessException {
		Session session = null;
		BlogsEntity blogs = null;
		logger.info("getBlog: Start");
		try {
			session = getSession();
			blogs = (BlogsEntity) session.get(BlogsEntity.class, blogsId);
			List<BlogsCommentEntity> blogComments = blogs.getBlogsComment();
			Collections.sort(blogComments);
			blogs.setBlogsComment(blogComments);
		} catch (HibernateException e) {
			logger.error("getBlog: " + e.getMessage(), e);
			throw new HmsDataAccessException("unable to get blog for given id: ", e);
		} finally {
			closeSession(session);
		}
		return blogs;
	}
	
	/**
	 * @param blogsComment
	 * @throws HmsDataAccessException
	 */
	@Override
	public boolean saveComments(BlogsCommentDto blogsComment) throws HmsDataAccessException {
		Session session = null;
		boolean flag = false;
		BlogsCommentEntity blogComments = new BlogsCommentEntity();
		logger.info("saveComments: Start");
		try {
			session = getSession();
			BlogsEntity blogs = (BlogsEntity) session.get(BlogsEntity.class, blogsComment.getBlogsId());
			if (HmsConstant.NULL != blogs) {
				blogComments.setBlogs(blogs);
				blogComments.setCommentDesc(blogsComment.getCommentDesc());
				blogComments.setCreatedDate(blogsComment.getCreatedDate());
				session.save(blogComments);
				session.flush();
				flag = true;
			}
		} catch (HibernateException e) {
			logger.error("saveComments: " + e.getMessage(), e);
			throw new HmsDataAccessException("Unable to save comments",	e);
		} finally {
			closeSession(session);
		}
		return flag;
	}
	

}
