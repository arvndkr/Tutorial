/**
 * 
 */
package com.hms;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;


/**
 * @author ARVIND
 *
 */
/*This class is used to set Spring security.*/
@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {	
	
	/**
	 * This method configures spring security settings.
	 */
    @Override
    protected void configure(HttpSecurity http) throws Exception {       
        http
	        .authorizeRequests()
		        .antMatchers("/admin/*").hasRole("ADMIN")
		        .anyRequest().authenticated()
		        .and()
            .authorizeRequests()            
                 //Allow all the urls you mention here 
                .antMatchers("/", "/scripts/**", "/css/**", "/images/**").permitAll()
                .anyRequest().authenticated()
                .and()
            .formLogin()
                .loginPage("/authenticate")
                .loginProcessingUrl("/login")
                .defaultSuccessUrl("/home")
                .permitAll()
                .and()
            .logout()
                .permitAll()
                .and()
            .csrf().disable();
    	}
    
    @Override
    public void configure(WebSecurity web) throws Exception {
      web.ignoring().antMatchers("/*.js", "/*.css");
    }

    /**
     * This method configures Users with spring security.
     * @param auth
     * @throws Exception
     */
    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication().withUser("user").password("user").roles("USER");
        auth.inMemoryAuthentication().withUser("admin").password("admin").roles("ADMIN");		
    }    
   
}
