package com.hms.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "expense_category")
public class ExpenseCategoryEntity implements Comparable<ExpenseCategoryEntity>{

	private int expCatId;
	private String expCat;
	private String expCatType;
	private List<ExpenseDetailsEntity> expDet = new ArrayList<ExpenseDetailsEntity>();	
	
	/**
	 * @return the expCatId
	 */
	@Id
	@Column(name = "exp_cat_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getExpCatId() {
		return this.expCatId;
	}

	/**
	 * @param expCatId the expCatId to set
	 */
	public void setExpCatId(int expCatId) {
		this.expCatId = expCatId;
	}

	/**
	 * @return the expCat
	 */
	@Column(name = "exp_cat")
	public String getExpCat() {
		return this.expCat;
	}

	/**
	 * @param expCat the expCat to set
	 */
	public void setExpCat(String expCat) {
		this.expCat = expCat;
	}	
	/**
	 * @return the expCatType
	 */
	@Column(name = "exp_cat_type")
	public String getExpCatType() {
		return this.expCatType;
	}

	/**
	 * @param expCatType the expCatType to set
	 */
	public void setExpCatType(String expCatType) {
		this.expCatType = expCatType;
	}

	/**
	 * @return the expDet
	 */
	@OneToMany(mappedBy = "expCat", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	public List<ExpenseDetailsEntity> getExpDet() {
		return this.expDet;
	}

	/**
	 * @param expDet the expDet to set
	 */
	public void setExpDet(List<ExpenseDetailsEntity> expDet) {
		this.expDet = expDet;
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ExpenseCategoryEntity o) {
		// TODO Auto-generated method stub
		return 0;
	}	

}
