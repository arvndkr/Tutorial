/**
 * 
 */
package com.hms.constant;

/**
 * @author M1028078
 *
 */
public interface HmsConstant {

	String DATE_FROMAT = "yyyy-MM-dd";
	String MONTH_YEAR_FROMAT = "yyyy-MM";
	public Object NULL = null;
	int ZERO = 0;
	int ONE = 1;
	public String NON_EXPENSE = "Non Expense";
	public String EXPENSE = "Expense";
	
	public int CAT_ID_ADD = 1;
	public int CAT_ID_CASHBACK = 2;
	public int CAT_ID_DAILY_USE = 3;
	public int CAT_ID_REFUND = 9;
	public int CAT_ID_SHOPPING = 10;
	
	public int LOAN_ID = 32;
	
	public String DAILY_USE = "Daily Use";
	public String SHOPPING = "Shopping";
	public String TRIP_PARTY_FRIENDS = "Trip/ Party (Friends)";
	public String TRIP_PARTY_SELF = "Trip/ Party (Self)";
	
	public int FROM_DATE_CC_HDFC = 21;
	public int TO_DATE_CC_HDFC = 20;
	public int FROM_DATE_CC_CITI = 17;
	public int TO_DATE_CC_CITI = 16;
	public int MONTH_DIFF = 1;
	
	public int BANK_ID_CC_HDFC = 1;
	public int BANK_ID_CC_CITI = 2;
	public int BANK_ID_CC_YES = 9;
}
