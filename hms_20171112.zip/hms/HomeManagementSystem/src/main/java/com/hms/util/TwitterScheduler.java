/**
 * 
 */
package com.hms.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @author ARVIND
 *
 */
@Component
public class TwitterScheduler {	
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	//This will run in every two minutes.
	@Scheduled(cron="0 0/2 * 1/1 * ?")
    public void saveTwitterData() {
		logger.info("It will fetch all twitter data related to topic and store in DB:");
		//TwitterScrap twitter = new TwitterScrap();
		//twitter.startTwitter();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			logger.error("saveTwitterData: " + e.getMessage(), e);
		}
		//twitter.stopTwitter();
    }

}
