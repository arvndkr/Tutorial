package com.hms.exception;

public class HmsDataAccessException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	/**
	 * 
	 */
	public HmsDataAccessException() {
		super();
	}

	/**
	 * @param message
	 * @param cause
	 */
	public HmsDataAccessException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public HmsDataAccessException(String message) {
		super(message);
	}	

}
