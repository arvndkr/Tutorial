/**
 * 
 */
package com.hms.dto;

/**
 * @author ARVIND
 *
 */
public class BankDetailsDto implements Comparable<BankDetailsDto> {

	private int bankId;
	private String bankName;
	private String accType;
	/**
	 * @return the bankId
	 */
	public int getBankId() {
		return this.bankId;
	}
	/**
	 * @param bankId the bankId to set
	 */
	public void setBankId(int bankId) {
		this.bankId = bankId;
	}
	/**
	 * @return the bankName
	 */
	public String getBankName() {
		return this.bankName;
	}
	/**
	 * @param bankName the bankName to set
	 */
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}	
	/**
	 * @return the accType
	 */
	public String getAccType() {
		return this.accType;
	}
	/**
	 * @param accType the accType to set
	 */
	public void setAccType(String accType) {
		this.accType = accType;
	}
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(BankDetailsDto bankDto) {
		return accType.compareTo(bankDto.getAccType());
	}
	
}
