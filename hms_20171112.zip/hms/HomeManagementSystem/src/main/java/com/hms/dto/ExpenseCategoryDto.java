/**
 * 
 */
package com.hms.dto;

/**
 * @author ARVIND
 *
 */
public class ExpenseCategoryDto implements Comparable<ExpenseCategoryDto> {

	private int expCatId;
	private String expCat;
	private String expCatType;
	/**
	 * @return the expCatId
	 */
	public int getExpCatId() {
		return this.expCatId;
	}
	/**
	 * @param expCatId the expCatId to set
	 */
	public void setExpCatId(int expCatId) {
		this.expCatId = expCatId;
	}
	/**
	 * @return the expCat
	 */
	public String getExpCat() {
		return this.expCat;
	}
	/**
	 * @param expCat the expCat to set
	 */
	public void setExpCat(String expCat) {
		this.expCat = expCat;
	}	
	/**
	 * @return the expCatType
	 */
	public String getExpCatType() {
		return this.expCatType;
	}
	/**
	 * @param expCatType the expCatType to set
	 */
	public void setExpCatType(String expCatType) {
		this.expCatType = expCatType;
	}
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	@Override
	public int compareTo(ExpenseCategoryDto expCatDto) {
		return expCat.compareTo(expCatDto.getExpCat());
	}
	
}
