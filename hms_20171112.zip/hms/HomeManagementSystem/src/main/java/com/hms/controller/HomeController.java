package com.hms.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author ARVIND
 *This class is used to handle request coming from home Page.
 */
@Controller
public class HomeController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * This method is used to redirect to login page.
	 * @return
	 */
	@RequestMapping(value = {"/authenticate", "/login", "/"})
	public ModelAndView getLoginPage() {
		logger.info("Login page");
		return new ModelAndView("login");
	}	
	
	/**
	 * @return
	 */
	@RequestMapping(value = {"/logout"})
	public ModelAndView logout() {
		logger.info("/logout page");
		return new ModelAndView("login");
	}
	
	/**
	 * @return
	 */
	@RequestMapping(value = "/home", method = {RequestMethod.POST,RequestMethod.GET})
	public String getHomePage() {
		logger.info("Redirecting To Home Page");
		return "home";
	}
	
}
