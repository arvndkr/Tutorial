package com.hms.util;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.hms.constant.HmsConstant;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * @author ARVIND
 *
 */
@Component
public class FileUploadUtil {

	public List<String> uploadFiles(List<MultipartFile> files,
			List<String> filePath, String rootPath) {
		File dir = new File(rootPath + File.separator + "resources");
		if (!dir.exists()){
			dir.mkdirs();
		}
		if (HmsConstant.NULL != files && files.size() > 0) {
			String finalPath = "";
			for (MultipartFile multipartFile : files) {

				String fileName = multipartFile.getOriginalFilename();
				if (!("".equalsIgnoreCase(fileName))) {					
					try {
						finalPath = dir.getAbsolutePath() + File.separator + fileName;
						multipartFile.transferTo(new File(finalPath));
					} catch (IllegalStateException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					filePath.add(fileName);
				}
			}

		}
		return filePath;
	}
}
