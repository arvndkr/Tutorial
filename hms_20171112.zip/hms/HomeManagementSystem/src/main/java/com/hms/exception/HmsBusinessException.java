package com.hms.exception;

public class HmsBusinessException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * @param message
	 * @param cause
	 */
	public HmsBusinessException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param message
	 */
	public HmsBusinessException(String message) {
		super(message);
	}	

}
