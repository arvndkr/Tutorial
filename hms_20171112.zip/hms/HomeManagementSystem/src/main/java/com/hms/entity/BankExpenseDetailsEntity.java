package com.hms.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author M1028078
 *
 */
@Entity
@Table(name = "bank_expense_details")
public class BankExpenseDetailsEntity{

	private int bankExpId;
	private float creditAmnt;
	private float debitAmnt;
	private float availableBalance;
	private Date txnDate;
	private BankDetailsEntity bankDetails;
	private ExpenseCategoryEntity expCat;
	private ExpenseDetailsEntity expDet;
	private String txnComment;
	/**
	 * @return the bankId
	 */
	@Id
	@Column(name = "bank_expense_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	public int getBankExpId() {
		return this.bankExpId;
	}
	/**
	 * @param bankId the bankId to set
	 */
	public void setBankExpId(int bankExpId) {
		this.bankExpId = bankExpId;
	}
	/**
	 * @return the creditAmnt
	 */
	@Column(name = "credit_amnt")
	public float getCreditAmnt() {
		return this.creditAmnt;
	}
	/**
	 * @param creditAmnt the creditAmnt to set
	 */
	public void setCreditAmnt(float creditAmnt) {
		this.creditAmnt = creditAmnt;
	}
	/**
	 * @return the debitAmnt
	 */
	@Column(name = "debit_amnt")
	public float getDebitAmnt() {
		return this.debitAmnt;
	}
	/**
	 * @param debitAmnt the debitAmnt to set
	 */
	public void setDebitAmnt(float debitAmnt) {
		this.debitAmnt = debitAmnt;
	}	
	/**
	 * @return the availableBalance
	 */
	@Column(name = "available_balance")
	public float getAvailableBalance() {
		return this.availableBalance;
	}
	/**
	 * @param availableBalance the availableBalance to set
	 */
	public void setAvailableBalance(float availableBalance) {
		this.availableBalance = availableBalance;
	}
	/**
	 * @return the txnDate
	 */
	@Column(name = "txn_date")
	public Date getTxnDate() {
		return this.txnDate;
	}
	/**
	 * @param txnDate the txnDate to set
	 */
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}
	/**
	 * @return the bankDetails
	 */
	@ManyToOne
	@JoinColumn(name = "bank_id")
	public BankDetailsEntity getBankDetails() {
		return this.bankDetails;
	}
	/**
	 * @param bankDetails the bankDetails to set
	 */
	public void setBankDetails(BankDetailsEntity bankDetails) {
		this.bankDetails = bankDetails;
	}
	/**
	 * @return the expCat
	 */
	@ManyToOne
	@JoinColumn(name = "exp_cat_id")
	public ExpenseCategoryEntity getExpCat() {
		return this.expCat;
	}
	/**
	 * @param expCat the expCat to set
	 */
	public void setExpCat(ExpenseCategoryEntity expCat) {
		this.expCat = expCat;
	}
	/**
	 * @return the expDet
	 */
	@ManyToOne
	@JoinColumn(name = "expense_id")
	public ExpenseDetailsEntity getExpDet() {
		return this.expDet;
	}
	/**
	 * @param expDet the expDet to set
	 */
	public void setExpDet(ExpenseDetailsEntity expDet) {
		this.expDet = expDet;
	}	
	/**
	 * @return the txnComment
	 */
	@Column(name = "txn_comment")
	public String getTxnComment() {
		return this.txnComment;
	}
	/**
	 * @param txnComment the txnComment to set
	 */
	public void setTxnComment(String txnComment) {
		this.txnComment = txnComment;
	}	
	
}
