/**
 * 
 */
package com.hms.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hms.constant.HmsConstant;

/**
 * @author ARVIND
 *
 */
public class CalendarUtil {
	
	private final static Logger logger = LoggerFactory.getLogger(CalendarUtil.class);
	
	/**
	 *  It will return month year.
	 * @param date
	 * @return
	 */
	public static String parseDateToMonthYearString(Date date){
		SimpleDateFormat sdf = new SimpleDateFormat(HmsConstant.MONTH_YEAR_FROMAT);
		if (HmsConstant.NULL == date) {
			date = new Date();
		}
		String month = sdf.format(date);
		return month;
	}
	
	/**
	 *  It will return month year.
	 * @param String
	 * @return
	 */
	public static String parseMonthYearString(String month){
		Date date = null;
		SimpleDateFormat sdf = new SimpleDateFormat(HmsConstant.MONTH_YEAR_FROMAT);
		if (StringUtil.isNullOrEmpty(month)) {
			date = new Date();
			month = sdf.format(date);
		} 
		if (month.length() > 7) {
			try {
				date = sdf.parse(month);
			} catch (ParseException e) {
				logger.error("parseMonthYearString: " + e.getMessage(), e);
			}
			month = sdf.format(date);
		}
		return month;
	}
	
	/**
	 * It will set default date as 1st of month.
	 * @param monthStr
	 * @return
	 */
	public static Date parseStringToMonthYear(String monthStr){
		SimpleDateFormat sdf = new SimpleDateFormat(HmsConstant.MONTH_YEAR_FROMAT);
		Date date = null;
		try {
			if (StringUtil.isNullOrEmpty(monthStr)) {
				date = new Date();
			} else {
				date = sdf.parse(monthStr);
			}
		} catch (ParseException e) {
			logger.error("parseStringToMonthYear: " + e.getMessage(), e);
		}
		return date;
	}
	
	/**
	 * @param dateStr
	 * @return
	 */
	public static Date parseStringToDate(String dateStr){
		SimpleDateFormat sdf = new SimpleDateFormat(HmsConstant.DATE_FROMAT);
		Date date = null;
		try {
			if (StringUtil.isNullOrEmpty(dateStr)) {
				date = new Date();
			} else {
				date = sdf.parse(dateStr);
			}
		} catch (ParseException e) {
			logger.error("parseStringToDate: " + e.getMessage(), e);
		}
		return date;
	}
	
	/**
	 * @param inputDate
	 * @param dateOfMonth
	 * @param monthDiff
	 * @return
	 */
	public static Date getModifiedDate(Date inputDate, int dateOfMonth, int monthDiff){
		Date resultDate = null;
		Calendar cal = Calendar.getInstance();
		cal.setTime(inputDate);
		cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) - monthDiff);
		cal.set(Calendar.DAY_OF_MONTH, dateOfMonth);
		resultDate = cal.getTime();
		logger.error("getModifiedDate: resultDate: " + resultDate);
		return resultDate;
	}
	
	/**
	 * @param inputDate
	 * @param criteria
	 * @return
	 */
	public static int getCalenderTime(Date inputDate, int criteria){
		Calendar cal = Calendar.getInstance();
		cal.setTime(inputDate);
		int res = cal.get(criteria);
		return res;
	}

}
