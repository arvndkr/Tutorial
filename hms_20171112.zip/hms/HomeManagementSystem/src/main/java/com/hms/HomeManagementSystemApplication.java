package com.hms;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.hibernate4.LocalSessionFactoryBuilder;

import com.hms.entity.BankDetailsEntity;
import com.hms.entity.BankExpenseDetailsEntity;
import com.hms.entity.BlogsAttachmentEntity;
import com.hms.entity.BlogsCommentEntity;
import com.hms.entity.BlogsEntity;
import com.hms.entity.ExpenseCategoryEntity;
import com.hms.entity.ExpenseDetailsEntity;

@SpringBootApplication
public class HomeManagementSystemApplication {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public static void main(String[] args) {
		SpringApplication.run(HomeManagementSystemApplication.class, args);
	}
	
	@Autowired
	@Bean(name = "sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource) {
		logger.info("Session factory initialization started");
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);
		sessionBuilder.addAnnotatedClasses(BlogsEntity.class);
		sessionBuilder.addAnnotatedClasses(BlogsCommentEntity.class);
		sessionBuilder.addAnnotatedClasses(BlogsAttachmentEntity.class);
		
		sessionBuilder.addAnnotatedClasses(BankDetailsEntity.class);
		sessionBuilder.addAnnotatedClasses(ExpenseCategoryEntity.class);
		sessionBuilder.addAnnotatedClasses(BankExpenseDetailsEntity.class);
		sessionBuilder.addAnnotatedClasses(ExpenseDetailsEntity.class);
		logger.info("Session factory initialization successful");
		return sessionBuilder.buildSessionFactory();
	}
}
