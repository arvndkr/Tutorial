/**
 * 
 */
package com.hms.dao;

import java.util.Date;
import java.util.List;

import com.hms.dto.BankDetailsDto;
import com.hms.dto.BankExpenseDetailsDto;
import com.hms.dto.ExpenseCategoryDto;
import com.hms.dto.ExpenseDetailsDto;
import com.hms.dto.ExpenseReportDto;
import com.hms.exception.HmsDataAccessException;

/**
 * @author ARVIND
 *
 */
public interface ExpenseDao {

	/**
	 * @param selectedMonth
	 * @return
	 * @throws HmsDataAccessException
	 */
	List<ExpenseDetailsDto> getAllExpense(Date selectedMonth) throws HmsDataAccessException;

	/**
	 * @param expCatType 
	 * @return
	 * @throws HmsDataAccessException
	 */
	List<ExpenseCategoryDto> getAllCategory(String expCatType) throws HmsDataAccessException;

	/**
	 * @return
	 * @throws HmsDataAccessException
	 */
	List<BankDetailsDto> getAllBanks() throws HmsDataAccessException;

	/**
	 * @param expDetDto
	 * @return
	 * @throws HmsDataAccessException
	 */
	boolean addExpense(ExpenseDetailsDto expDetDto) throws HmsDataAccessException;

	/**
	 * @param bankExpDetailDto
	 * @return
	 * @throws HmsDataAccessException
	 */
	boolean addBankExpense(BankExpenseDetailsDto bankExpDetailDto) throws HmsDataAccessException;

	/**
	 * @param selectedMonth
	 * @return
	 * @throws HmsDataAccessException
	 */
	Double getTotalExpense(Date selectedMonth) throws HmsDataAccessException;

	/**
	 * @param selectedMonth
	 * @return
	 * @throws HmsDataAccessException
	 */
	ExpenseReportDto getMonthlyExpenseReport(Date selectedMonth) throws HmsDataAccessException;

}
