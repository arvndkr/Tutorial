/*function myDate(){
	var date = document.getElementById("dateId").value;
	document.getElementById("expDateStr").value = date;
	console.log("hi: " + document.getElementById("expDateStr").value);
}*/

/*function myDate(){
	var date = $('#dateId').val();
	$('#expDateStr').val(date);
}*/

function myTxnDate(){
	var date = $('#dateId').val();
	$('#txnDateStr').val(date);
}

function getAllExpense(){
	var month = $('#monthId').val();
	
	window.location = '/getAllExpense?month=' + month;
	
	/*$.ajax({
		type : "GET",
		url : "getAllExpense",
		data : {
			month : month
		},
		beforeSend: function(){
			$('#ajaxmask').show();
		},
		success : function(data){
			$('#infoManagementFilterId').html(data);
		},
		complete: function(){
			$('#ajaxmask').hide();
		}
	});*/
}

/*function selectToBank(){
	var expCatId = document.getElementById("expCatId").value;
	if(expCatId == 11){
		document.getElementById("toBankIdDiv").style.display = 'block';
	}
}*/

function selectToBank(){
	var expCatId = $('#expCatId').val();
	/*Transfer*/
	if(expCatId == 11){
		$('#toBankIdDiv').show();
	} else {
		$('#toBankIdDiv').hide();
	}
}

function showMonthlyExpenseReport(){
	var month = $('#monthId').val();
	
	window.location = '/showMonthlyExpenseReport?month=' + month;
}