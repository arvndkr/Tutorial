-- MySQL dump 10.11
--
-- Host: localhost    Database: home_management_system
-- ------------------------------------------------------
-- Server version	5.5.52

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE database `home_management_system`;

USE home_management_system;
--
-- Table structure for table `bank_details`
--

DROP TABLE IF EXISTS `bank_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bank_details` (
  `bank_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `bank_name` varchar(45) NOT NULL UNIQUE DEFAULT '',
  `account_type` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `bank_details`
--

LOCK TABLES `bank_details` WRITE;
/*!40000 ALTER TABLE `bank_details` DISABLE KEYS */;
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (1, 'HDFC Credit Card', 'Credit Card');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (2, 'CITI Credit Card', 'Credit Card');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (3, 'CITI Saving Ac', 'Saving Account');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (4, 'CITI Current Ac', 'Current Account');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (5, 'SBI PPF', 'PF');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (6, 'SBI Saving Ac', 'Saving Account');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (7, 'IDFC Saving Ac', 'Saving Account');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (8, 'PNB BLR', 'Saving Account');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (9, 'PNB LKO', 'Saving Account');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (10, 'EPF', 'PF');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (11, 'CASH Mine', 'CASH');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (12, 'CASH Saved', 'CASH');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (13, 'CASH Shruti', 'CASH');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (15, 'Food Coupan', 'Food Coupan');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (16, 'PayZap 81977', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (17, 'PayZap 87470', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (18, 'Tapzo 81977', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (19, 'Tapzo 87470', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (20, 'FreeCharge 81977', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (21, 'FreeCharge 87470', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (22, 'FreeCharge 88535', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (23, 'FreeCharge cse', 'Mobile Wallet');

INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (25, 'Paytm 81977', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (26, 'Paytm 87470', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (27, 'MobiKwik 81977', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (28, 'MobiKwik 87470', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (29, 'Amazon 81977', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (30, 'Ola 81977', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (31, 'Ola 87470', 'Mobile Wallet');
INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (32, 'Loan', 'Loan');

INSERT INTO `bank_details` (bank_id, bank_name, account_type) VALUES (34, 'Airtel 81977', 'Mobile Bank');

/*!40000 ALTER TABLE `bank_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bank_expense_details`
--

DROP TABLE IF EXISTS `bank_expense_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `bank_expense_details` (
  `bank_expense_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `credit_amnt` float NOT NULL DEFAULT '0',
  `debit_amnt` float NOT NULL DEFAULT '0',
  `available_balance` float NOT NULL DEFAULT '0',
  `txn_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `bank_id` int(10) unsigned NOT NULL DEFAULT '0',
  `exp_cat_id` int(10) unsigned NOT NULL DEFAULT '0',
  `expense_id` int(10) unsigned,
  `txn_comment` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`bank_expense_id`),
  KEY `expense_id` (`expense_id`),
  KEY `bank_id` (`bank_id`),
  KEY `expns_cat_id` (`exp_cat_id`),
  CONSTRAINT `bank_id` FOREIGN KEY (`bank_id`) REFERENCES `bank_details` (`bank_id`),
  CONSTRAINT `expense_id` FOREIGN KEY (`expense_id`) REFERENCES `expense_details` (`expense_id`),
  CONSTRAINT `expns_cat_id` FOREIGN KEY (`exp_cat_id`) REFERENCES `expense_category` (`exp_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `expense_category`
--

DROP TABLE IF EXISTS `expense_category`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `expense_category` (
  `exp_cat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `exp_cat` varchar(45) NOT NULL UNIQUE DEFAULT '',
  `exp_cat_type` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`exp_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `expense_category`
--

LOCK TABLES `expense_category` WRITE;
/*!40000 ALTER TABLE `expense_category` DISABLE KEYS */;
INSERT INTO `expense_category` VALUES (1,'Add Money','Non Expense'),(2,'Cash Back','Non Expense'),(3,'Daily Use','Expense'),(4,'Family','Expense'),(5,'Trip/ Party (Friends)','Expense'),(6,'Trip/ Party (Self)','Expense');
INSERT INTO `expense_category` VALUES (7,'Loan Given','Non Expense'),(8,'Recharges','Expense'),(9,'Refund','Non Expense'),(10,'Shopping','Expense'),(11,'Transfer','Non Expense'),(12,'Unused','Expense un');
INSERT INTO `expense_category` VALUES (13,'Loan Return','Non Expense');
/*!40000 ALTER TABLE `expense_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expense_details`
--

DROP TABLE IF EXISTS `expense_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `expense_details` (
  `expense_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `expense_amnt` float NOT NULL DEFAULT '0',
  `expense_date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `exp_cat_id` int(10) unsigned NOT NULL DEFAULT '0',
  `expense_comment` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`expense_id`),
  KEY `exp_cat_id` (`exp_cat_id`),
  CONSTRAINT `exp_cat_id` FOREIGN KEY (`exp_cat_id`) REFERENCES `expense_category` (`exp_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;


/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-02 17:04:44
